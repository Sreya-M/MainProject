
<?php 
session_start();
include 'connection.php';
if (isset($_SESSION['id'])) {


$ri = $_SESSION['id'];

$name=$_POST['name'];
$uid=$_POST['uid'];
$hname=$_POST['hname'];
$mob=$_POST['mobile'];


                $ri = $_SESSION['id'];
                $query = "select * from tbl_panchayath where login_id='$ri'";
                $res = mysqli_query($conn, $query);
                $r = mysqli_fetch_array($res);
                $pid=$r["panch_id"]; 
		  
	
		$sql1="INSERT INTO `tbl_cntlist`(`pt_id`, `ct_name`, `ct_honame`, `ct_mob`) 
        VALUES ('$uid','$name','$hname','$mob')";
       if(mysqli_query($conn,$sql1))
	   {
		   if(headers_sent()){
		   die('<script type="text/javascript">window.location.href="ashaviewpstv.php?e=1"</script>');
		   }
		   else {
		   header("location:ashaviewpstv.php?e=1");
		   die();
		   }
	   }
	
  
 
  else {

	echo "Error: " . $sql . "<br>" . mysqli_error($conn);
  }
}
  mysqli_close($conn);
?>
