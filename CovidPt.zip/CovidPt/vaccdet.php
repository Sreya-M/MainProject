<?php
session_start();
include 'connection.php';
if (isset($_SESSION['id'])) {
?>
<?php
        $ri = $_SESSION['id'];
        
        $query = "select * from tbl_register where login_id='$ri'";
        $res = mysqli_query($conn, $query);
        $r = mysqli_fetch_array($res);
        $kname=$r['name'];
       
        ?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Covid Preventocity</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="assets/img/icon.jpg" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="assets/vendor/remixicon/remixicon.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">

  <!-- =======================================================
  * Template Name: OnePage - v4.7.0
  * Template URL: https://bootstrapmade.com/onepage-multipurpose-bootstrap-template/
  * Author: BootstrapMade.com
  * License: https://bootstrapmade.com/license/
  ======================================================== -->

  
  <style>

    /* CSS */
.button-2 {
  background-color: rgba(51, 51, 51, 0.05);
  border-radius: 8px;
  border-width: 0;
  color: #333333;
  cursor: pointer;
  display: inline-block;
  font-family: "Haas Grot Text R Web", "Helvetica Neue", Helvetica, Arial, sans-serif;
  font-size: 14px;
  font-weight: 500;
  line-height: 20px;
  list-style: none;
  margin: 0;
  padding: 10px 12px;
  text-align: center;
  transition: all 200ms;
  vertical-align: baseline;
  white-space: nowrap;
  user-select: none;
  -webkit-user-select: none;
  touch-action: manipulation;
}
  </style>
</head>

<body>

  <!-- ======= Header ======= -->
  <header id="header" class="fixed-top">
    <div class="container d-flex align-items-center justify-content-between">

      <h1 class="logo"><a href="index.html">Covid Preventocity</a></h1>
      <!-- Uncomment below if you prefer to use an image logo -->
      <!-- <a href="index.html" class="logo"><img src="assets/img/logo.png" alt="" class="img-fluid"></a>-->

      <nav id="navbar" class="navbar">
        <ul>
          <li><a class="nav-link scrollto active" href="panchhome.php">Home</a></li>
          <li><a class="nav-link scrollto" href="ashaworker.php">Ashaworker</a></li>
          <li><a class="nav-link scrollto" href="vaccine.php">Vaccine Details</a></li>
          <li><a class="nav-link scrollto" href="panchviewhos.php">Hospitals</a></li>
         

         <!-- <li><a href="#"><span>Wards</span></i></a></li>-->
            
          <!--<li><a class="nav-link scrollto" href="#team">Containment Zones</a></li>
           <li><a class="nav-link scrollto" href="#pricing">Asha </a></li>-->
           <li class="dropdown"><a href="#"><span>Wards</span> <i class="bi bi-chevron-down"></i></a>
            <ul>
              <li><a href="viewward.php">List Ward</a></li>
              <li><a href="zoneview.php">Containment Zone</a></li>
            </ul>
          </li>
          <?php
        $ri = $_SESSION['id'];
        
        $query = "select * from tbl_panchayath where login_id='$ri'";
        $res = mysqli_query($conn, $query);
        $r = mysqli_fetch_array($res);
        ?>
        
          <li class="nav-item dropdown pe-3">

<a class="nav-link nav-profile d-flex align-items-center pe-0" href="#" data-bs-toggle="dropdown">
  
  <span><b><?php echo $r['panch_name']; ?></b></span><i  class="bi bi-chevron-down"></i>
</a><!-- End Profile Iamge Icon -->

<ul>
<li><a class="nav-link scrollto" href="panchprofile.php">Profile</a></li>
 </ul>

          <li><a class="getstarted scrollto" href="logout.php">LOGOUT</a></li>
          

        </ul>
        <i class="bi bi-list mobile-nav-toggle"></i>
      </nav><!-- .navbar -->

    </div>
  </header><!-- End Header -->

  
<?php
                $ri = $_SESSION['id'];
                $query = "select * from tbl_panchayath where login_id='$ri'";
                $res = mysqli_query($conn, $query);
                $r = mysqli_fetch_array($res);
                $pid=$r["panch_id"];
                $pn=$r['panch_name']; 
?>





      <main id="main">
        <!-- ======= About Section ======= -->
        <section id="about" class="about">
          <div class="container" data-aos="fade-up">
          <a href ="vaccine.php">
<button class="button-2" role="button">Back</button></a>
<a href ="vaccreq.php">
<button class="button-2" role="button" >Vaccine Request</button></a>
<form action="vaccpdf.php" method="POST">
                <!-- <input type="text" name="eid" value="<?php echo $c_id ?>" hidden > -->
                <input type="text" name="rid" value="<?php echo $pid ?>" hidden >

<button class="button-2" name="generatepdf" role="button">Report</button></form> 
            <div class="section-title">
              <h2>Vaccines in <?php echo $pn ?> Panchayath </h2>
              <p> </p>
            </div>
            <section class="section dashboard">
      <div class="row">

      <div class="col-lg-12">

         
          
           
            <table class="table table-bordered">
                <thead>
                  <tr>
                  <th scope="col">Vaccine Name</th>                   
                   
                    <th scope="col">Number of Dose</th>  
                    <th scope="col">Intervel</th>  

                    <th scope="col">Availability</th>  
                    <th scope="col" colspan="2">Actions</th>  


                   


                      
                  </tr>
                </thead>
                <tbody>
                <!-- php query for view hospital -->
                <?php

              
              

                $sql="SELECT * from tbl_panchvacc where panch_id='$pid'";

                $sql2="SELECT tbl_panchvacc.*,tbl_vacc.* from tbl_panchvacc join tbl_vacc where tbl_panchvacc.vac_id=tbl_vacc.vac_id AND tbl_panchvacc.panch_id='$pid'";
                
                
                # $sql1="SELECT name,panch_id FROM tbl_hospital ";
                 $result = $conn->query($sql2);
                 
                 if ($result->num_rows > 0) {
                   // output data of each row
                   while($row = $result->fetch_assoc()) { ?>
                    
                    <tr>
                    <td><?php echo$row["vac_name"]; ?></td>
                    <td><?php echo$row["numdose"]; ?></td>                     
                    <td><?php echo$row["intervel"]; ?></td>
                    <td><?php echo$row["avail"]; ?></td>
                    <td> 
                     <button class="btn btn-primary"><a href="editvacav.php?eid=<?php echo $row['vac_id'];?>" class="text-light">Edit Availability</a></button>
                     
                   
                    </td>
                   
                     </tr>
                     
                   <?php  
                   
                   }
                 } else {
                   echo "0 results";
                 }
                 $conn->close();
                 ?>
                 
                     
                   
                     
                  </tbody>
            </table>
           <!-- <div class="text-center">
            <button class="btn btn-primary"><a href="addvacc.php" class="text-light">
                      Add New Vaccine</a></button>
                </div> -->

        
      </div>
    </div>
</section>
          </div>
        </section><!-- End About Section -->
        
        



      </main><!-- End #main -->

      <!-- ======= Footer ======= -->
      <footer id="footer">

        <div class="footer-top">
          <div class="container">
            <div class="row">

              <div class="col-lg-3 col-md-6 footer-contact">
                <h3>Covid Preventocity</h3>
                <p>
                  MCA <br>
                  Amal Jyothi<br>
                  Kanjirappally <br><br>
                  <strong>Phone:</strong> 123333<br>
                  <strong>Email:</strong> info@example.com<br>
                </p>
              </div>
            </div>
          </div>
        </div>
      </footer><!-- End Footer -->

      <div id="preloader"></div>
      <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

      <!-- Vendor JS Files -->
      <script src="assets/vendor/purecounter/purecounter.js"></script>
      <script src="assets/vendor/aos/aos.js"></script>
      <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
      <script src="assets/vendor/glightbox/js/glightbox.min.js"></script>
      <script src="assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
      <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>
      <script src="assets/vendor/php-email-form/validate.js"></script>

      <!-- Template Main JS File -->
      <script src="assets/js/main.js"></script>

</body>

</html>

<?php
} else {
  if (headers_sent()) {
    die('<script type="text/javascript">window.location.href="login.php?e=1"</script>');
  } else {
    header("location:login.php?e=1");
    die();
  }
}
?>    