<?php 
session_start();

include('connection.php');
include('pdf_table.php');
if(isset($_POST['generatepdf']))
{
    $pid=$_POST['rid'];
    $query = "select * from tbl_panchayath where panch_id='$pid'";
                $res = mysqli_query($conn, $query);
                $r = mysqli_fetch_array($res);
                
               

  $result = mysqli_query($conn,"select * from tbl_wards where panch_id='$pid'") or die(mysqli_error($con));
  $pdf = new PDF_MC_TABLE();
  $pdf->AddPage();

  $pdf->SetFont('Arial', 'B', 15);
  $pdf->Cell(176, 5, 'Ward Details', 0, 0, 'C');
  $pdf->Ln();
  $pdf->Ln();
  $pdf->Ln();

  $pdf->SetFont('Arial','',10);
  
  $pdf->SetWidths(Array(11,30,30,30,40));

  $pdf->SetLineHeight(5);

  $pdf->SetFont('Arial','B',10);
  $pdf->Multicell(80,12,'Panchayath Name : '. $r['panch_name'],1);
  $pdf->Cell(11,5,"Sl No",1,0);
  $pdf->Cell(30,5,"Ward Number",1,0);
  $pdf->Cell(30,5,"Member Name",1,0);
  $pdf->Cell(30,5,"Member Number",1,0);
  $pdf->Cell(40,5,"Member Email",1,0);
  
  $pdf->Ln();
  
  $pdf->SetFont('Arial','',10);	
  $i=1;
  foreach($result as $row) {
    $pdf->Row(Array(
        $i,
		$row['ward_num'],
        $row['ward_mem_name'],
		$row['ward_mem_numb'],
		$row['ward_mem_email'],
		
	));
	$i++;
  }
  $pdf->Output();
}
?>
