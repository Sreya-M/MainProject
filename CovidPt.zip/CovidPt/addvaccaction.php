
<?php 
session_start();
include 'connection.php';
if (isset($_SESSION['id'])) {


$ri = $_SESSION['id'];

$name=$_POST['vname'];
$nod=$_POST['nod'];
$int=$_POST['int'];



		  
				
		$sql1="INSERT INTO `tbl_vacc`( `vac_name`, `intervel`, `numdose`) VALUES ('$name','$int','$nod')";
       if(mysqli_query($conn,$sql1))
	   {
		   if(headers_sent()){
		   die('<script type="text/javascript">window.location.href="adminvaccine.php?e=1"</script>');
		   }
		   else {
		   header("location:adminvaccine.php?e=1");
		   die();
		   }
	   }
	
  
 
  else {

	echo "Error: " . $sql . "<br>" . mysqli_error($conn);
  }
}
  mysqli_close($conn);
?>
