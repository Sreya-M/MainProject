<?php
	include 'connection.php';

    $name=$_POST['name'];
	$panch=$_POST['panch'];
    $mob=$_POST['mobile'];
    $email=$_POST['emailid'];
    $uname=$_POST['username'];
	$pwd=$_POST['passwd'];
	$adhar=$_POST['adhar'];
 
   
	$sel1="select * from `tbl_login` where `username`='$uname'";
	$result=mysqli_query($conn,$sel1);
	$num=mysqli_num_rows($result);
	 if($num>0)
	  {
	 ?>
	 <script> 
	  alert("Username already in exist");
	</script>
	  <?php
	  }
	  else
	  {
		  
	$sql="INSERT INTO `tbl_login`(`username`,`passwd`,`type`,`status`) VALUES('$uname','$pwd','3','1')";
	if(mysqli_query($conn,$sql))
	{
		$result1=mysqli_query($conn,"select * from tbl_login where username='$uname'");
		$row=mysqli_fetch_assoc($result1);
		$sql1="INSERT INTO `tbl_register`(`login_id`,`panch_id`,`name`,`email`,`Phone`,`adhar`) VALUES('$row[login_id]','$panch','$name','$email','$mob','$adhar')";
		if(mysqli_query($conn,$sql1))
		{
			if(headers_sent()){
			die('<script type="text/javascript">window.location.href="login.php?e=1"</script>');
			}
			else {
			header("location:login.php?e=1");
			die();
			}
		}

	}
	else {
		?>
		<script>
		alert("error");
		</script>
		<?php
		}
}

mysqli_close($conn);			
?> 
	
   