<?php 

include("connection.php");

$name=$_POST['name'];
$pname=$_POST['prename'];
$pmob=$_POST['mobile'];
$pemail=$_POST['emailid'];
$ppass=$_POST['pass'];
$pward=$_POST['ward'];


$sel1="select * from `tbl_login` where `username`='$pemail'";
	$result=mysqli_query($conn,$sel1);
	$num=mysqli_num_rows($result);
	 if($num>0)
	  {
	 ?>
	 <script> 
	  alert("Username already in exist");
	</script>
	  <?php
	  }
	  else
	  {
		  
	$sql="INSERT INTO `tbl_login`(`username`,`passwd`,`type`,`status`) VALUES('$pemail','$ppass','4','1')";
	if(mysqli_query($conn,$sql))
	{
		$result1=mysqli_query($conn,"select * from tbl_login where `username`='$pemail'");
		$row=mysqli_fetch_assoc($result1);
		$sql1="INSERT INTO `tbl_panchayath`(`login_id`, `panch_name`, `panch_president_name`, `panch_mobile`, `panch_email`,`num_wards`)
		 VALUES('$row[login_id]','$name','$pname','$pmob','$pemail','$pward')";
       if(mysqli_query($conn,$sql1))
	   {
		   if(headers_sent()){
		   die('<script type="text/javascript">window.location.href="viewpanch.php?e=1"</script>');
		   }
		   else {
		   header("location:viewpanch.php?e=1");
		   die();
		   }
	   }
	}
  
 
  else {

	echo "Error: " . $sql . "<br>" . mysqli_error($conn);
  }
}
  mysqli_close($conn);
?>