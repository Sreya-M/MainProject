<?php
session_start();
include 'connection.php';

if (isset($_SESSION['id'])) {
?>

<?php
        $ri = $_SESSION['id'];
        
        $query = "select * from tbl_hospital where login_id='$ri'";
        $res = mysqli_query($conn, $query);
        $r = mysqli_fetch_array($res);
        ?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Covid Preventocity</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="assets/img/icon.jpg" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="assets/vendor/remixicon/remixicon.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">

  <!-- =======================================================
  * Template Name: OnePage - v4.7.0
  * Template URL: https://bootstrapmade.com/onepage-multipurpose-bootstrap-template/
  * Author: BootstrapMade.com
  * License: https://bootstrapmade.com/license/
  ======================================================== -->
</head>

<body>

  <!-- ======= Header ======= -->
  <header id="header" class="fixed-top">
    <div class="container d-flex align-items-center justify-content-between">

      <h1 class="logo"><a href="hospitalhome.php">Covid Preventocity</a></h1>
      <!-- Uncomment below if you prefer to use an image logo -->
      <!-- <a href="index.html" class="logo"><img src="assets/img/logo.png" alt="" class="img-fluid"></a>-->

      <nav id="navbar" class="navbar">
        <ul>
          <li><a class="nav-link scrollto active" href="hospitalhome.php">Home</a></li>
         
          
         
          <li class="dropdown"><a href="#"><span> Appoinments</span> <i class="bi bi-chevron-down"></i></a>
            <ul>
              <li><a href="hosappoinmntphy.php">Physicians</a></li>
              <li><a href="hosappoinmntpsy.php">Psychologist</a></li></ul></li>

         <!--  <li><a class="nav-link scrollto" href="sss.php">Covid Test</a></li>
           <li><a class="nav-link scrollto" href="#pricing">Pricing</a></li>-->
           <li><a class="nav-link scrollto" href="patients.php">Covid Patients</a></li>
           <li class="dropdown"><a href="#"><span> Doctor</span> <i class="bi bi-chevron-down"></i></a>
            <ul>
              <li><a href="hosviewdoc.php">Doctor List</a></li>
              <li><a href="hosdocschdate.php">Doctor Schedule</a></li></ul></li>
           <!-- <li><a class="nav-link scrollto" href="hosviewdoc.php">Doctor</a></li>
           <li><a class="nav-link scrollto" href="hosdocschdate.php">Doctor Sched</a></li> -->

          <li class="dropdown"><a href="#"><span> Services</span> <i class="bi bi-chevron-down"></i></a>
            <ul>
              <li><a href="hosvacc.php">Vaccine</a></li>
              <li><a href="hospanch.php">Panchayath</a></li>

              <li class="dropdown"><a href="#"><span>Covid Test</span> <i class="bi bi-chevron-right"></i></a>
                <ul>
                  <li><a href="hosctant.php">Antigen</a></li>
                  <li><a href="hosctrt.php">RTPCR</a></li>
                  

                </ul>
              </li>
              
            </ul>
          </li>
          <li class="nav-item dropdown pe-3">

          <a class="nav-link nav-profile d-flex align-items-center pe-0" href="#" data-bs-toggle="dropdown">
            <img src="assets/img/n.png" alt="Profile" class="rounded-circle">
            <span><b><?php echo $r['name']; ?></b></span><i  class="bi bi-chevron-down"></i>
          </a><!-- End Profile Iamge Icon -->

          <ul>
            <li>
              
              <span><a href="hosprofile.php"> Profile</a></span>
            </li>
           </ul>
          <li><a class="getstarted scrollto" href="logout.php">LOGOUT</a></li>
        </ul>
        <i class="bi bi-list mobile-nav-toggle"></i>
      </nav><!-- .navbar -->

    </div>
  </header><!-- End Header -->

  


      

      <main id="main">


      <section class="breadcrumbs">
      <div class="container">

        <div class="d-flex justify-content-between align-items-center">
          <h2>Antigen</h2>
          
        </div>

      </div>
    </section>
        <!-- ======= About Section ======= -->
        <section id="about" class="about">
          <div class="container" data-aos="fade-up">
            
            <div class="section-title">
              
              <p> </p>
            </div>
             

            <section class="section dashboard">
      <div class="row">

      <div class="col-lg-12">

         
          
           
            <table class="table table-bordered">
              
                  
            <thead>
                  <tr>
                  <th scope="col">Name</th>                   
                   
                    <th scope="col">Age</th>
                    <th scope="col">Adhar</th>
                    <th scope="col">Panchayath</th>
                   
                    <th scope="col">Email</th>
                    <th scope="col">Contact Number</th>
                    <th scope="col">Status</th>
                    <th scope="col">Result</th>

                    
                    
                   


                      
                  </tr>
                </thead>
                <tbody>
                <!-- php query for view hospital -->
                <?php

              
              
$ri = $_SESSION['id'];
$query = "select * from tbl_hospital where login_id='$ri'";
$res = mysqli_query($conn, $query);
$r = mysqli_fetch_array($res);
$pid=$r["h_id"];
 

      
              
               
                

$sql1="SELECT tbl_cvdtest.*,tbl_panchayath.* FROM tbl_cvdtest JOIN tbl_panchayath ON
                tbl_cvdtest.panch_id=tbl_panchayath.panch_id AND tbl_cvdtest.hos_id='$pid' AND tbl_cvdtest.type='2' ";



 $result = $conn->query($sql1);
 
 if ($result->num_rows > 0) {
   // output data of each row
   while($row = $result->fetch_assoc()) { ?>
    
    <tr>
   
                     
    <td><?php echo$row["tpname"]; ?></td>
    <td><?php echo$row["age"]; ?></td>
    <td><?php echo$row["adhar"]; ?></td>
    <td><?php echo$row["panch_name"]; ?></td>
    
    <td><?php echo$row["ctemail"]; ?></td>
    <td><?php echo$row["ctmobile"]; ?></td>
    
    <td><?php echo$row["status"]; ?></td>
    <td><?php echo$row["result"]; ?></td>
<?php

    if($row["status"]=="Registered"){ ?>
    </td><td><a href="hosctantup.php?uid=<?php echo $row['ctest_id'];?>">
                    <button class="btn btn-primary" class="text-light" id="btn" value="Block" >Tested</button>
                  </a></td>
                  <?php } else if($row["result"]=="Pending"){ ?> 
                  
                  <td><a href="hosctresupl.php?uid=<?php echo $row['ctest_id'];?>">
                    <button class="btn btn-primary" class="text-light" id="btn" value="Block">Result Upload</button>
                  </a></td>
                  <?php } else if($row["estatus"]=="Pending"){ ?> 
                  
                  <td><a href="hosctresemail.php?email=<?php echo $row['ctemail'];?>&&vid= <?php echo $row['ctest_id'];?>">
                    <button class="btn btn-primary" class="text-light" id="btn" value="Block">Sent Email</button>
                  </a></td>
                  
                  <?php }  else {?>
                  <td><a href="hosctresupl.php?uid=<?php echo $row['ctest_id'];?>">
                    <button class="btn btn-primary" class="text-light" id="btn" value="Block" hidden >Sent Email</button>
                  </a></td>
                      <?php } ?>

               


     
   
     </tr>
     
   <?php  
                   
                   }
                 } else {
                   echo "0 results";
                 }
                 $conn->close();
                 ?>
                 
                     
                   
                     
                  </tbody>
            </table>
          
      </main><!-- End #main -->

      <!-- ======= Footer ======= -->
      <footer id="footer">

        <div class="footer-top">
          <div class="container">
            <div class="row">

              <div class="col-lg-3 col-md-6 footer-contact">
                <h3>Covid Preventocity</h3>
                <p>
                  MCA <br>
                  Amal Jyothi<br>
                  Kanjirappally <br><br>
                  <strong>Phone:</strong> 123333<br>
                  <strong>Email:</strong> info@example.com<br>
                </p>
              </div>
            </div>
          </div>
        </div>
      </footer><!-- End Footer -->

      <div id="preloader"></div>
      <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

      <!-- Vendor JS Files -->
      <script src="assets/vendor/purecounter/purecounter.js"></script>
      <script src="assets/vendor/aos/aos.js"></script>
      <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
      <script src="assets/vendor/glightbox/js/glightbox.min.js"></script>
      <script src="assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
      <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>
      <script src="assets/vendor/php-email-form/validate.js"></script>

      <!-- Template Main JS File -->
      <script src="assets/js/main.js"></script>

</body>

</html>
<?php
} else {
  if (headers_sent()) {
    die('<script type="text/javascript">window.location.href="login.php?e=1"</script>');
  } else {
    header("location:login.php?e=1");
    die();
  }
}
?>    