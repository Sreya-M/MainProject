<?php

$pt_id=$_GET['eid'];


include('connection.php');

$a='Negative';


mysqli_query($conn,"update `tbl_pstvlist` set pstv_status='$a' where pst_id='$pt_id'");




	header('location:viewcontdet.php');

?>
