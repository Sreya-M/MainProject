<?php
session_start();
include 'connection.php';
if (isset($_SESSION['id'])) {
?>
<?php
        $ri = $_SESSION['id'];
        
        $query = "select * from tbl_register where login_id='$ri'";
        $res = mysqli_query($conn, $query);
        $r = mysqli_fetch_array($res);
        $kname=$r['name'];
       
        ?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Covid Preventocity</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="assets/img/icon.jpg" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="assets/vendor/remixicon/remixicon.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">

  <!-- =======================================================
  * Template Name: OnePage - v4.7.0
  * Template URL: https://bootstrapmade.com/onepage-multipurpose-bootstrap-template/
  * Author: BootstrapMade.com
  * License: https://bootstrapmade.com/license/
  ======================================================== -->



</head>

<body>

  <!-- ======= Header ======= -->
  <header id="header" class="fixed-top">
    <div class="container d-flex align-items-center justify-content-between">

      <h1 class="logo"><a href="index.html">CovidPreventocity</a></h1>
      <!-- Uncomment below if you prefer to use an image logo -->
      <!-- <a href="index.html" class="logo"><img src="assets/img/logo.png" alt="" class="img-fluid"></a>-->

      <nav id="navbar" class="navbar">
        <ul>
        <li><a class="nav-link scrollto active" href="userhome.php">Home</a></li>
          
          <li><a class="nav-link scrollto" href="uservaccview.php">Vaccine</a></li>
          <li><a class="nav-link scrollto" href="userregvacc.php">Vaccine Status</a></li>
          <li class="dropdown"><a href=""><span> Appoinments</span> <i class="bi bi-chevron-down"></i></a>
            <ul>
            <li class="dropdown"><a href="#"><span>New Appoinments</span><i class="bi bi-chevron-right"></i></a>
              <ul>
              <li><a href="userappoinmntphyview.php">Physicians</a></li>
              <li class="dropdown"><a href="userappoinmntpsyview.php"><span>Psychologist</span> </a>
              </ul>
              <li><a href="userregappmt.php">Registered Appoinments</a></li>
</ul>
         
          <li class="dropdown"><a href="#"><span> Services</span> <i class="bi bi-chevron-down"></i></a>
            <ul>
              
              <li class="dropdown"><a href="usercntmtzone.php"><span>Containment Zone</span></a>
                
              </li>
              
            </ul>
          </li>
          
          <li class="dropdown"><a href="#"><span>CovidTest</span> <i class="bi bi-chevron-down"></i></a>
                <ul>
                  <li><a href="usercovidtest.php">Register</a></li>
                  <li><a href="userctestres.php">Result</a></li>
                  

                </ul>
              </li>
              <li class="nav-item dropdown pe-3">
              <a class="nav-link nav-profile d-flex align-items-center pe-0" href="#" data-bs-toggle="dropdown">
  <!-- <img src="assets/img/n.png" alt="Profile" class="rounded-circle"> -->
  <span><b><?php echo $r['name']; ?></b></span><i  class="bi bi-chevron-down"></i>
</a><!-- End Profile Iamge Icon -->

<ul>
  <li>
    
    <span><a href="userprofile.php"> Profile</a></span>
  </li>
 </ul>
        
          <li><a class="getstarted scrollto" href="logout.php">LOGOUT</a></li>
        </ul>
        <i class="bi bi-list mobile-nav-toggle"></i>
      </nav><!-- .navbar -->
    </div>
  </header><!-- End Header -->

  <main id="main">

    <!-- ======= Breadcrumbs ======= -->
    <section class="breadcrumbs">
      <div class="container">

        <div class="d-flex justify-content-between align-items-center">
          <h2>Vaccine Register</h2>
          
        </div>

      </div>
    </section><!-- End Breadcrumbs -->

    <section id="about" class="about">
          <div class="container" data-aos="fade-up">
            
            <div class="section-title">
              
              <p> </p>
            </div>
             

            <section class="section dashboard">
      <div class="row">

      <div class="col-lg-12">

      
   
 
          
            <table class="table table-bordered">
              
                  
            <thead>
                  <tr>
                                   


                  <th scope="col">Hospital Name</th>                   

                  <th scope="col">Vaccine Name</th>                   
                   
                    <th scope="col">Available Dose Count</th>  
                    <th scope="col">Date</th>  
                    <th scope="col">Time</th>  
                   
                    
                   


                      
                  </tr>
                </thead>
                <tbody>
                <!-- php query for view hospital -->
                <?php

              
              

$sql1="SELECT  `tbl_hosvacc`.*,tbl_hosvaccsch.*,tbl_vacc.*,tbl_hospital.name,tbl_timeset.setslots
FROM tbl_hosvacc JOIN tbl_vacc ON tbl_hosvacc.vac_id=tbl_vacc.vac_id 
JOIN tbl_hospital ON tbl_hospital.h_id=tbl_hosvacc.hos_id
JOIN tbl_hosvaccsch ON tbl_hosvacc.hvac_id=tbl_hosvaccsch.hvac_id AND tbl_hosvaccsch.status='1'
JOIN tbl_timeset ON tbl_timeset.tset_id=tbl_hosvaccsch.tset_id ";



 $result = $conn->query($sql1);
 
 if ($result->num_rows > 0) {
   // output data of each row
   while($row = $result->fetch_assoc()) { 
   
    ?>
    
    <tr>
   
    <td><?php echo$row["name"]; ?></td>                 
    <td><?php echo$row["vac_name"]; ?></td>
    <td><?php echo $row["num"]; ?></td>
    <td><?php echo$row["date"]; ?></td>
    <td><?php echo$row["setslots"]; ?></td>
    
   <td>
   
     <button class="btn btn-primary"><a href="uservaccreg.php?uid=<?php echo $row['hvs_id'];?>" class="text-light">
                      Register</a></button></td>
     


     
   
     </tr>
     
   <?php  
                   
                   }
                 } else {
                   echo "0 results";
                 }
                 $conn->close();
                 ?>
                 
                     
                   
                     
                  </tbody>
            </table>
          
  </main><!-- End #main -->

 <!-- ======= Footer ======= -->
 <footer id="footer">

<div class="footer-top">
  <div class="container">
    <div class="row">

      <div class="col-lg-3 col-md-6 footer-contact">
        <h3>Covid Preventocity</h3>
        <p>
          MCA <br>
          Amal Jyothi<br>
          Kanjirappally <br><br>
          <strong>Phone:</strong> 123333<br>
          <strong>Email:</strong> info@example.com<br>
        </p>
      </div>
    </div>
  </div>
</div>
</footer><!-- End Footer -->

  <div id="preloader"></div>
  <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

  <!-- Vendor JS Files -->
  <script src="assets/vendor/purecounter/purecounter.js"></script>
  <script src="assets/vendor/aos/aos.js"></script>
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/glightbox/js/glightbox.min.js"></script>
  <script src="assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
  <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>

  <!-- Template Main JS File -->
  <script src="assets/js/main.js"></script>

</body>

</html>
<?php
} else {
  if (headers_sent()) {
    die('<script type="text/javascript">window.location.href="login.php?e=1"</script>');
  } else {
    header("location:login.php?e=1");
    die();
  }
}
?>    


