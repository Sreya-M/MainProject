<?php
	include 'connection.php';
  
  if(isset($_SESSION['login_id']))
{
  
  
    
  $id=$_GET['id'];
  $query="SELECT * FROM tbl_login where login_id ='$id'";
  $res = mysqli_query($con,$query);
  $r=mysqli_fetch_array($res);
  $sel_query="UPDATE tbl_login SET status = 0 WHERE login_id ='$id'";
  $result = mysqli_query($con,$sel_query);
  if(mysqli_query($con,$sel_query))
    { 
      if(headers_sent())
         {
          ?>
          <script>
            alert("Mechanic blocked Successfully");
            </script>
            <?php
           die('<script type="text/javascript">window.location.href="viewpanch.php"</script>');
         }


    }
  }  
  else
  {
      if(headers_sent())
          {
               die('<script type="text/javascript">window.location.href="viewpanch.php?e=1"</script>');
           }
  else
  {
  header("location:viewpanch.php?e=1");
  die();
  }

} 

  
?>

  


