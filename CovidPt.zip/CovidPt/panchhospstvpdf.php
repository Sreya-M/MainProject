<?php 
session_start();

include('connection.php');
include('pdf_table.php');
if(isset($_POST['generatepdf']))
{
    $pid=$_POST['rid'];
    $ho_id=$_POST['uid'];
    $query = "select * from tbl_panchayath where panch_id='$pid'";
                $res = mysqli_query($conn, $query);
                $r = mysqli_fetch_array($res);

                $query1 = "select * from tbl_hospital where h_id='$ho_id'";
                $res1 = mysqli_query($conn, $query1);
                $r1 = mysqli_fetch_array($res1);
               
               

  $result = mysqli_query($conn,"SELECT tbl_posthos.pt_id,tbl_posthos.pt_name,tbl_posthos.cdate,tbl_posthos.pt_mob,
  tbl_posthos.panch_id,tbl_wards.ward_num from tbl_posthos JOIN tbl_wards
   on tbl_wards.ward_id =tbl_posthos.ward_num AND tbl_posthos.panch_id='$pid' AND tbl_posthos.h_id='$ho_id'") or die(mysqli_error($con));
  $pdf = new PDF_MC_TABLE();
  $pdf->AddPage();

  $pdf->SetFont('Arial', 'B', 15);
  $pdf->Cell(176, 5, 'Positive Details', 0, 0, 'C');
  $pdf->Ln();
  $pdf->Ln();
  $pdf->Ln();

  $pdf->SetFont('Arial','',10);
  
  $pdf->SetWidths(Array(11,30,30,35,30));

  $pdf->SetLineHeight(5);

  $pdf->SetFont('Arial','B',10);
  $pdf->Multicell(80,12,'Panchayath Name : '. $r['panch_name'],1);
  $pdf->Multicell(80,12,'Hospital Name : '. $r1['name'],1);
  $pdf->Cell(11,5,"Sl No",1,0);
  $pdf->Cell(30,5,"Ward Number",1,0);
  $pdf->Cell(30,5,"Name of Positive",1,0);
  $pdf->Cell(35,5,"Contact of Positive",1,0);
  $pdf->Cell(30,5,"Date of Positive",1,0);
  
  $pdf->Ln();
  
  $pdf->SetFont('Arial','',10);	
  $i=1;
  foreach($result as $row) {
    $pdf->Row(Array(
        $i,
		$row['ward_num'],
        $row['pt_name'],
		$row['pt_mob'],
		$row['cdate'],
		
	));
	$i++;
  }
  $pdf->Output();
}
?>
