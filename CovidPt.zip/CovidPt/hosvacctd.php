<?php

$r_id=$_GET['uid'];


include('connection.php');




mysqli_query($conn,"UPDATE `tbl_usvacc` SET `vstatus`='Vaccinated' WHERE uvc_id='$r_id'");

 



	header('location:hosvaccbook.php');

?>
