<?php
session_start();
include 'connection.php';

if (isset($_SESSION['id'])) 
{    

   $pid=$_GET['uid'];
    $ri=$_SESSION['id'];


         $result=mysqli_query($conn,"SELECT `tbl_usvacc`.*,tbl_register.*,tbl_hosvaccsch.*,tbl_hosvacc.*,tbl_vacc.vac_name,tbl_hospital.name FROM tbl_usvacc JOIN tbl_register ON tbl_usvacc.user_id=tbl_register.r_id JOIN tbl_hosvaccsch ON tbl_hosvaccsch.hvs_id=tbl_usvacc.hvs_id JOIN
         tbl_hosvacc ON tbl_hosvacc.hvac_id=tbl_hosvaccsch.hvac_id JOIN tbl_vacc ON tbl_vacc.vac_id=tbl_hosvacc.vac_id JOIN tbl_hospital ON tbl_hospital.h_id=tbl_hosvacc.hos_id AND tbl_usvacc.uvc_id='$pid'") or die(mysqli_error($con));

// $result=mysqli_query($con,"SELECT first_name,last_name,age,gender,parent_name,paddress,caddress,email,phone_no,license_type,date_of_issue,expiriry_date,blood FROM `tbl_drivinglicense` where driving_id=$driving_id") or die(mysqli_error($con));


include('pdf_table.php');
class PDF extends FPDF {
  
    // Page header
    function Header() {
          
        // Add logo to page
        $this->Image('assets\img\cer1.png',45,8,130);	
          
        // // Set font family to Arial bold 
        // $this->SetFont('Arial','B',20);
          
        // // Move to the right
        // $this->Cell(80);
          
        // // Header
        // $this->Cell(50,10,'Heading',1,0,'C');
          
        // // Line break
        $this->Ln(60);
        $this->Image('assets\img\sign.png',150,228,50);	
        $this->Image('assets\img\footer.png',0,278,230);	
    }
    
 
}

$pdf = new PDF_MC_TABLE();
$pdf = new PDF();
$pdf->AddPage();
$pdf->SetFont('Times','B',14);

$pdf->Cell(50,10,'Beneficiary Details',0,0,'U'); 

$row=mysqli_fetch_array($result);
$pdf->SetFont('Times','',12);	
$pdf->Ln();
$pdf->cell(0,12,'Name : '. $row['uvname']);
$pdf->Ln();
$pdf->cell(80,12,'Age : '. $row['uvage']);$pdf->Ln();
$pdf->cell(80,12,'Adhar : '. $row['uvadhar']);$pdf->Ln();
$pdf->SetFont('Times','B',14);

$pdf->Cell(50,10,'Vaccination Details',0,0,''); 
$pdf->SetFont('Times','',12);	
$pdf->Ln();
$pdf->cell(80,12,'Vaccine Name : '. $row['vac_name']);$pdf->Ln();
$pdf->cell(80,12,'Vaccine Dose : '. $row['vdose']);$pdf->Ln();
$pdf->cell(80,12,'Vaccinated Date : '. $row['vdate']);$pdf->Ln();
$pdf->cell(80,12,'Vaccinated Place : '. $row['name']);$pdf->Ln();
$pdf->Output();

}
?>