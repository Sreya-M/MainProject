<?php
session_start();
include 'connection.php';

if (isset($_SESSION['id'])) 
{    

   $pid=$_GET['uid'];
    $ri=$_SESSION['id'];


         $result=mysqli_query($conn,"SELECT tbl_cvdtest.*,tbl_panchayath.*,tbl_hospital.*,tbl_login.login_id FROM tbl_cvdtest
         JOIN tbl_panchayath ON tbl_cvdtest.panch_id=tbl_panchayath.panch_id
         JOIN tbl_hospital ON tbl_hospital.h_id=tbl_cvdtest.hos_id
         JOIN tbl_login ON tbl_login.login_id=tbl_cvdtest.log_id  AND tbl_cvdtest.ctest_id=$pid") or die(mysqli_error($con));

// $result=mysqli_query($con,"SELECT first_name,last_name,age,gender,parent_name,paddress,caddress,email,phone_no,license_type,date_of_issue,expiriry_date,blood FROM `tbl_drivinglicense` where driving_id=$driving_id") or die(mysqli_error($con));


include('pdf_table.php');
$pdf = new PDF_MC_TABLE();
$pdf->AddPage();
$pdf->SetFont('Arial','B',15);	
$pdf->Cell(176, 5, 'Result Details', 0, 0, 'C');
  $pdf->Ln();
  $pdf->Ln();
  $pdf->Ln();	
$row=mysqli_fetch_array($result);
$pdf->SetFont('Arial','',12);	
$pdf->Multicell(80,12,'Name : '. $row['tpname'],1);
$pdf->Multicell(80,12,'Age : '. $row['age'],1);
$pdf->Multicell(80,12,'Adhar : '. $row['adhar'],1);
$pdf->Multicell(80,12,'Date : '. $row['tdate'],1);
$pdf->Multicell(80,12,'Type ofTest : '. $row['type'],1);
$pdf->Multicell(80,12,'Panchayath : '. $row['panch_name'],1);
$pdf->Multicell(80,12,'Mobile Number : '. $row['ctmobile'],1);
$pdf->Multicell(80,12,'Email : '. $row['ctemail'],1);
$pdf->Multicell(80,12,'Result : '. $row['result'],1);


$pdf->Output();


}
?>