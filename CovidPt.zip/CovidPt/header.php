<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body>
    <center>
        <br>
        <table bgcolor="#B9C2EB" border="0" width="80%">
            <tr colspan="3">
                <td>
                    <font color="white">
                        <h2><b>CovidPreventocity</b></h2>
                </td>
            </tr>
            <tr align="right">
                <td></td>
                <td width="100px" bgcolor="#8DE7FA" align="center"><b><a href="index.php">Home</a></b> </td>
                <td width="100px" bgcolor="#8DE7FA" align="center"><b><a href="login.php">Login</a></b> </td>
                <td width="100px" bgcolor="#8DE7FA" align="center"><b><a href="reghome.html">SignUp</a></b> </td>
            </tr>

        </table>
    </center>
</body>

</html>