<?php
session_start();
include 'connection.php';
if (isset($_SESSION['id'])) {

  

?>
<?php
  $ri = $_SESSION['id'];
  
  $query = "select * from tbl_hospital where login_id='$ri'";
  $res = mysqli_query($conn, $query);
  $r = mysqli_fetch_array($res);
  ?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Covid Preventocity</title>
  <meta content="" name="description">
  <meta content="" name="keywords">


<script>
$('.datepicker').datepicker({
  weekdaysShort: ['Su', 'Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa'],
  showMonthsShort: true
})
</script>
  <!-- Favicons -->
  <link href="assets/img/icon.jpg" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="assets/vendor/remixicon/remixicon.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.13.0/css/all.min.css">
    <link rel="stylesheet" href="assets/css/bootstrap-datetimepicker.min.css">
  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">

  <!-- =======================================================
  * Template Name: OnePage - v4.7.0
  * Template URL: https://bootstrapmade.com/onepage-multipurpose-bootstrap-template/
  * Author: BootstrapMade.com
  * License: https://bootstrapmade.com/license/
  ======================================================== -->



</head>

<body>
<header id="header" class="fixed-top">
    <div class="container d-flex align-items-center justify-content-between">

      <h1 class="logo"><a href="hospitalhome.php">Covid Preventocity</a></h1>
      <!-- Uncomment below if you prefer to use an image logo -->
      <!-- <a href="index.html" class="logo"><img src="assets/img/logo.png" alt="" class="img-fluid"></a>-->
      <nav id="navbar" class="navbar">
        <ul>
          <li><a class="nav-link scrollto active" href="hospitalhome.php">Home</a></li>
         
          
         
          <li class="dropdown"><a href="#"><span> Appoinments</span> <i class="bi bi-chevron-down"></i></a>
            <ul>
              <li><a href="hosappoinmntphy.php">Physicians</a></li>
              <li><a href="hosappoinmntpsy.php">Psychologist</a></li></ul></li>

         <!--  <li><a class="nav-link scrollto" href="sss.php">Covid Test</a></li>
           <li><a class="nav-link scrollto" href="#pricing">Pricing</a></li>-->
           <li><a class="nav-link scrollto" href="patients.php">Covid Patients</a></li>
           <li class="dropdown"><a href="#"><span> Doctor</span> <i class="bi bi-chevron-down"></i></a>
            <ul>
              <li><a href="hosviewdoc.php">Doctor List</a></li>
              <li><a href="hosdocschdate.php">Doctor Schedule</a></li></ul></li>
           <!-- <li><a class="nav-link scrollto" href="hosviewdoc.php">Doctor</a></li>
           <li><a class="nav-link scrollto" href="hosdocschdate.php">Doctor Sched</a></li> -->

          <li class="dropdown"><a href="#"><span> Services</span> <i class="bi bi-chevron-down"></i></a>
            <ul>
              <li><a href="hosvacc.php">Vaccine</a></li>
              <li><a href="hospanch.php">Panchayath</a></li>

              <li class="dropdown"><a href="#"><span>Covid Test</span> <i class="bi bi-chevron-right"></i></a>
                <ul>
                  <li><a href="hosctant.php">Antigen</a></li>
                  <li><a href="hosctrt.php">RTPCR</a></li>
                  

                </ul>
              </li>
              
            </ul>
          </li>
          <li class="nav-item dropdown pe-3">

          <a class="nav-link nav-profile d-flex align-items-center pe-0" href="#" data-bs-toggle="dropdown">
            <img src="assets/img/n.png" alt="Profile" class="rounded-circle">
            <span><b><?php echo $r['name']; ?></b></span><i  class="bi bi-chevron-down"></i>
          </a><!-- End Profile Iamge Icon -->

          <ul>
            <li>
              
              <span><a href="hosprofile.php"> Profile</a></span>
            </li>
           </ul>
          <li><a class="getstarted scrollto" href="logout.php">LOGOUT</a></li>
        </ul>
        <i class="bi bi-list mobile-nav-toggle"></i>
      </nav><!-- .navbar -->

    </div>
  </header><!-- End Header -->

   
    <main id="main">


    <!-- ======= Breadcrumbs ======= -->
    <section class="breadcrumbs">
      <div class="container">

        <div class="d-flex justify-content-between align-items-center">
          <h2>Manage Schedule</h2>
          
        </div>

      </div>
    </section><!-- End Breadcrumbs -->

    <section class="inner-page">
      <div class="container">

      <section class="section dashboard">
      <div class="row">

     

      <form  style="text-align: center;" class="row g-3" name="form" id="form" method="POST">
      
      <div class="form-group" >
      <div class="col-12">
            <div class="col-md-6">
              <h4>Select Date</h4>
            <div class="form-group">
                <div class="input-group date" id="datetimepicker1">
                    <input type="text" name="time" id="time"class="form-control" required readonly>
                    <div class="input-group-addon input-group-prepend">
                        <span class="input-group-text"><i class="fas fa-calendar"></i></span>
                    </div>
                </div>
            </div>
            </div>
            </div>
      </div>
						</div>                                     
            <div class="text-center">
                  <button type="submit" class="btn btn-primary" name="submit" id="submit"  value='Submit'>Search</button>
                  <button type="reset" class="btn btn-secondary">Reset</button>
                </div>
              </form>    
              
              <?php 
  if(isset($_POST['submit']))
             {
      $cid=$_POST['time'];
  ?>  
  <br>  
  <br>  
  <br>  
  <br>



            <table class="table">
              
                  
            <thead  class="thead-dark" >
                  <tr>
                   <th scope="col">Name</th>                   
                    <th scope="col">Specialization</th>  
                    <th scope="col">Departments</th> 
                    <th scope="col"></th>  

                     

                  </tr>
                </thead>
                <tbody>
                <!-- php query for view hospital -->
                <?php

              
              
$ri = $_SESSION['id'];
$query = "select * from tbl_hospital where login_id='$ri'";
$res = mysqli_query($conn, $query);
$r = mysqli_fetch_array($res);
$pid=$r["h_id"];
 

// $query1 = "select * from tbl_doctor where h_id=$pid";
// $res1 = mysqli_query($conn, $query1);
// $r1 = mysqli_fetch_array($res1);


      
              
               
                

$sql2="SELECT tbl_doctor.*,tbl_doc_cat.* from tbl_doctor 
JOIN tbl_doc_cat on tbl_doctor.cat_id=tbl_doc_cat.cat_id 
 AND  tbl_doctor.h_id='$pid' AND tbl_doctor.status='Active'";




 $result = $conn->query($sql2);
 
 if ($result->num_rows > 0) {
   // output data of each row
   while($row = $result->fetch_assoc()) { ?>
    
    <tr>
   
                     
    <td><?php echo$row["doc_name"]; ?></td>
    <td><?php echo$row["doc_spec"]; ?></td>
    <td><?php echo$row["ctype"]; ?></td>
    


    <td><form class="row g-3" name="form" id="form" method="POST" action="hosdocscdlact.php">
               
                
                
                <div class="col-md-6">
                  <label for="input" class="form-label"></label>
                  <input type="name" class="form-control" name="didd" id="didd" value="<?php echo $row['doc_id']; ?> " hidden >
                </div>
                <div class="col-md-6">
                  <label for="input" class="form-label"></label>
                  <input type="name" class="form-control" name="time" id="time" value="<?php echo $cid ?> " hidden>
                </div>
  
                
               
                
                <div class="text-center">
                  <button type="submit" class="btn btn-primary" name="submit" id="submit"  value='Submit'>Schedule</button>
                  
                </div>
              </form></td>

    <!-- <td><a href="hosdocscdlact.php?uid=<?php echo $row['doc_id'];?>">
      <button type="submit" class="btn btn-primary" name="sdl" id="sdl"  value='sdl'>Schedule</button></td>
     -->

    


     
   
     </tr>
     
   <?php  
                   
                   }
                 } else {
                   echo "0 results";
                 }
                 $conn->close();
                 ?>
                 
                     
                   
                     
                  </tbody>
            </table>
          
            <?php } ?>  

    
     
 <br>
 <br>
 <br>
 <br>
 <br>
 <br>
 <br>
 <br>
      <br>
                </div>
                </div>
                
                </div>
    </section>

  </main><!-- End #main -->

 <!-- ======= Footer ======= -->
 <br>
 <br>
 <br>
 <br>
 <br>
 <br>
 <br>
 <footer id="footer">

<div class="footer-top">
  <div class="container">
    <div class="row">

      <div class="col-lg-3 col-md-6 footer-contact">
        <h3>Covid Preventocity</h3>
        <p>
          MCA <br>
          Amal Jyothi<br>
          Kanjirappally <br><br>
          <strong>Phone:</strong> 123333<br>
          <strong>Email:</strong> info@example.com<br>
        </p>
      </div>
    </div>
  </div>
</div>
</footer><!-- End Footer -->

  <div id="preloader"></div>
  <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

  <!-- Vendor JS Files -->
  <script src="assets/vendor/purecounter/purecounter.js"></script>
  <script src="assets/vendor/aos/aos.js"></script>
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/glightbox/js/glightbox.min.js"></script>
  <script src="assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
  <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>

  <!-- Template Main JS File -->
  <script src="assets/js/main.js"></script>
  <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js" integrity="sha384-OgVRvuATP1z7JjHLkuOU7Xw704+h835Lr+6QL9UvYjZE3Ipu6Tp75j7Bh/kR0JKI" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.26.0/moment.min.js"></script>
    <script src="assets/js/bootstrap-datetimepicker.min.js"></script>
    <script>
        $(function () {
            $.extend(true, $.fn.datetimepicker.defaults, {
                icons: {
                    time: 'far fa-clock',
                    date: 'far fa-calendar',
                    up: 'fas fa-arrow-up',
                    down: 'fas fa-arrow-down',
                    previous: 'fas fa-chevron-left',
                    next: 'fas fa-chevron-right',
                    today: 'far fa-calendar-check-o',
                    clear: 'far fa-trash',
                    close: 'far fa-times'
                }
            });
        });
        </script>
        <script type="text/javascript">
            $(function () {
                $('#datetimepicker').datetimepicker({
                  ignoreReadonly: true
                });
            });

            $(function () {
                $('#datetimepicker1').datetimepicker({
                  format: 'YYYY-MM-DD',
                  ignoreReadonly: true
                });
            });

            $(function () {
                $('#datetimepicker2').datetimepicker({
                  format: 'hh:mm a',
                  ignoreReadonly: true
                });
            });

            $(function () {
                $('#datetimepicker3').datetimepicker({
                  format: 'HH:mm',
                  ignoreReadonly: true
                });
            });

            $(function () {
              var minDate = new Date();

              minDate.setDate(minDate.getDate()-5); // set days - mean previous date from current date + mean future date from current date

                $('#datetimepicker4').datetimepicker({
                  format: 'YYYY-MM-DD',
                  minDate: minDate,
                  ignoreReadonly: true
                });
            });

            $(function () {
              var minDate = new Date();
              var maxDate = new Date();

              minDate.setDate(minDate.getDate()-5); // set days - mean previous date from current date + mean future date from current date
              maxDate.setDate(maxDate.getDate()+10);
                $('#datetimepicker5').datetimepicker({
                  format: 'YYYY-MM-DD',
                  minDate: minDate,
                  maxDate: maxDate,
                  ignoreReadonly: true
                });
            });

        </script>
</body>

</html>
<?php
} else {
  if (headers_sent()) {
    die('<script type="text/javascript">window.location.href="login.php?e=1"</script>');
  } else {
    header("location:login.php?e=1");
    die();
  }
}
?>    


