<?php
session_start();
include 'connection.php';
if (isset($_SESSION['id'])) {
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Covid Preventocity</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="assets/img/icon.jpg" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="assets/vendor/remixicon/remixicon.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">

  <!-- =======================================================
  * Template Name: OnePage - v4.7.0
  * Template URL: https://bootstrapmade.com/onepage-multipurpose-bootstrap-template/
  * Author: BootstrapMade.com
  * License: https://bootstrapmade.com/license/
  ======================================================== -->
</head>

<body>

  <!-- ======= Header ======= -->
  <header id="header" class="fixed-top">
    <div class="container d-flex align-items-center justify-content-between">

      <h1 class="logo"><a href="index.html">Covid Preventocity</a></h1>
      <!-- Uncomment below if you prefer to use an image logo -->
      <!-- <a href="index.html" class="logo"><img src="assets/img/logo.png" alt="" class="img-fluid"></a>-->

      <nav id="navbar" class="navbar">
        <ul>
          <li><a class="nav-link scrollto active" href="panchhome.php">Home</a></li>
          <li><a class="nav-link scrollto" href="ashaworker.php">Ashaworker</a></li>
          <li><a class="nav-link scrollto" href="vaccine.php">Vaccine Details</a></li>
          <li><a class="nav-link scrollto" href="panchviewhos.php">Hospitals</a></li>
         

         <!-- <li><a href="#"><span>Wards</span></i></a></li>-->
            
          <!--<li><a class="nav-link scrollto" href="#team">Containment Zones</a></li>
           <li><a class="nav-link scrollto" href="#pricing">Asha </a></li>-->
           <li class="dropdown"><a href="#"><span>Wards</span> <i class="bi bi-chevron-down"></i></a>
            <ul>
              <li><a href="viewward.php">List Ward</a></li>
              <li><a href="zoneview.php">Containment Zone</a></li>
            </ul>
          </li>
          <?php
        $ri = $_SESSION['id'];
        
        $query = "select * from tbl_panchayath where login_id='$ri'";
        $res = mysqli_query($conn, $query);
        $r = mysqli_fetch_array($res);
        ?>
        
          <li class="nav-item dropdown pe-3">

<a class="nav-link nav-profile d-flex align-items-center pe-0" href="#" data-bs-toggle="dropdown">
  
  <span><b><?php echo $r['panch_name']; ?></b></span><i  class="bi bi-chevron-down"></i>
</a><!-- End Profile Iamge Icon -->

<ul>
<li><a class="nav-link scrollto" href="panchprofile.php">Profile</a></li>
 </ul>
         

          <li><a class="getstarted scrollto" href="logout.php">LOGOUT</a></li>
          

        </ul>
        <i class="bi bi-list mobile-nav-toggle"></i>
      </nav><!-- .navbar -->

    </div>
  </header><!-- End Header -->

 


      <main id="main">
        <!-- ======= About Section ======= -->
        <section id="about" class="about">
          <div class="container" data-aos="fade-up">

            <div class="section-title">
              <h2></h2>
              <p> </p>
            </div>
            <section class="section dashboard">
      <div class="row">

      <div class="col-lg-12">

      <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
<?php
include("connection.php");

      $chkresults = mysqli_query($conn,"SELECT `tdate`, COUNT(*) AS cvd_count FROM `tbl_cvdtest` GROUP BY tdate");

   

      ?>
      <h2>Covid Test </h2>
  <script type="text/javascript">

      google.charts.load('current', {'packages':['Line']});

      google.charts.setOnLoadCallback(drawChart);

 

      function drawChart() {

        var data = google.visualization.arrayToDataTable([

           ['tdate','tdate'],

         <?php

     

        while($row=mysqli_fetch_array($chkresults)){

           

           echo "['".$row["tdate"]."',".$row["cvd_count"]."],";

          }

         ?>

        ]);

        var options = {

          chart: {

            title: '',          

          },

          bars: 'vertical',

          vAxis: {format: 'decimal'},

          height: 300,

          colors: ['#d95f02']

        };

 

        var chart = new google.charts.Line(document.getElementById('line-chart-location'));

 

        chart.draw(data, google.charts.Line.convertOptions(options));

      }

    </script>

       

        <!--location where the line chart will be displayed-->

        <div style="width:50%" id="line-chart-location">

        </div>

          

        
      </div>
    </div>
</section>
          </div>
        </section><!-- End About Section -->
        
        



      </main><!-- End #main -->

      <!-- ======= Footer ======= -->
      <footer id="footer">

        <div class="footer-top">
          <div class="container">
            <div class="row">

              <div class="col-lg-3 col-md-6 footer-contact">
                <h3>Covid Preventocity</h3>
                <p>
                  MCA <br>
                  Amal Jyothi<br>
                  Kanjirappally <br><br>
                  <strong>Phone:</strong> 123333<br>
                  <strong>Email:</strong> info@example.com<br>
                </p>
              </div>
            </div>
          </div>
        </div>
      </footer><!-- End Footer -->

      <div id="preloader"></div>
      <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

      <!-- Vendor JS Files -->
      <script src="assets/vendor/purecounter/purecounter.js"></script>
      <script src="assets/vendor/aos/aos.js"></script>
      <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
      <script src="assets/vendor/glightbox/js/glightbox.min.js"></script>
      <script src="assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
      <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>
      <script src="assets/vendor/php-email-form/validate.js"></script>

      <!-- Template Main JS File -->
      <script src="assets/js/main.js"></script>

</body>

</html>

<?php
} else {
  if (headers_sent()) {
    die('<script type="text/javascript">window.location.href="login.php?e=1"</script>');
  } else {
    header("location:login.php?e=1");
    die();
  }
}
?>    