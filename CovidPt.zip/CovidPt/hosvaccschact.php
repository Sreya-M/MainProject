
<?php 
session_start();
include 'connection.php';
if (isset($_SESSION['id'])) {



$hvac=$_POST['didd'];
$num=$_POST['numb'];
$numbr=$num*10;
$date=$_POST['date'];
$time=$_POST['time'];
// $panch=$_POST['panch'];
// $mob=$_POST['mobile'];

               
$sql2="SELECT * FROM `tbl_hosvacc` WHERE `hvac_id` = '$hvac'";   
$res1 = mysqli_query($conn, $sql2);
 $r1 = mysqli_fetch_array($res1);
 $cnt=$r1['num_vacc'];
 $vact=$cnt-$num;
                
		  
	
		$sql1="INSERT INTO `tbl_hosvaccsch`(`hvac_id`, `tset_id`, `num`, `date`, `status`) 
        VALUES ('$hvac','$time','$numbr','$date','1')";
        $sql3="UPDATE `tbl_hosvacc` SET `num_vacc`='$vact' WHERE `hvac_id` = '$hvac'";
         
       if(mysqli_query($conn,$sql1))
	   {
        if(mysqli_query($conn,$sql3))
        {
		   if(headers_sent()){
		   die('<script type="text/javascript">window.location.href="hosvacc.php?e=1"</script>');
		   }
		   else {
		   header("location:hosvacc.php?e=1");
		   die();
		   }
        }
	   }
	
  
 
  else {

	echo "Error: " . $sql . "<br>" . mysqli_error($conn);
  }
}
  mysqli_close($conn);
?>
