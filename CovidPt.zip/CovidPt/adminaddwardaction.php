<?php 
session_start();
include 'connection.php';




$name=$_POST['name'];
$pname=$_POST['prename'];
$pmob=$_POST['mobile'];
$pemail=$_POST['emailid'];
$panch=$_POST['panch'];




	
		$sql1="INSERT INTO `tbl_wards`(`panch_id`, `ward_num`, `ward_mem_name`, `ward_mem_numb`, `ward_mem_email`) 
        VALUES ('$panch','$name','$pname','$pmob','$pemail')";
		echo $sql1;
       if(mysqli_query($conn,$sql1))
	   {
		   if(headers_sent()){
		   die('<script type="text/javascript">window.location.href="viewward.php?e=1"</script>');
		   }
		   else {
		   header("location:viewward.php?e=1");
		   die();
		   }
	   }
	
  
 
  else {

	echo "Error: " . $sql1 . "<br>" . mysqli_error($conn);
  }

  mysqli_close($conn);
?>
