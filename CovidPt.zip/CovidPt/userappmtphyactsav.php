
<?php 
session_start();
include 'connection.php';
if (isset($_SESSION['id'])) {




$name=$_POST['time'];
$sch=$_POST['scid'];

$result="SELECT * FROM `tbl_hosvaccsch` WHERE `hvs_id` = '$sch'";
$query = mysqli_query($conn, $result);
$row = mysqli_fetch_array($query);
$count=$row['num'];
$coun=$count-1;
mysqli_query($conn,"UPDATE `tbl_hosvaccsch` SET `num`='$coun' WHERE `hvs_id` = '$sch'");
mysqli_query($conn,"UPDATE `tbl_usvacc` SET `vtime`='$name' WHERE `hvs_id` = '$sch'");
header('location:userregvacc.php');
}
  mysqli_close($conn);
?>
