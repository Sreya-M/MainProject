<?php
session_start();

include("connection.php");



	$conn = mysqli_connect($servername, $username, $password);
	mysqli_select_db($conn, $db);
	$username = $_POST["username"];
	$passwd = $_POST["passwd"];
	$sql2 = "select * from tbl_login where username='" . $username . "' AND passwd='" . $passwd . "'";


	$result = mysqli_query($conn, $sql2);

	if ($result) {
		if ($row = mysqli_fetch_array($result)) {
			$_SESSION['id'] = $row['login_id'];
			if ($row[3] == "1") {
			?>	
				<script type="text/Javascript">
					window.location.href="adminpanel.php"</script>
			<?php
			} else if ($row[3] == "2"&& $row[4]== "1") {

			?>
				<script type="text/Javascript">
					window.location.href="hospitalhome.php"</script>
			<?php
			} else if ($row[3] == "3"&& $row[4]== "1") {
			?>
				<script type="text/Javascript">
					window.location.href="userhome.php"</script>
			<?php
			} else if ($row[3] == "4"&& $row[4]== "1") {

				?>
					<script type="text/Javascript">
						window.location.href="panchhome.php"</script>
				<?php
			
			} else if ($row[3] == "5"&& $row[4]== "1") {

				?>
					<script type="text/Javascript">
						window.location.href="ashahome.php"</script>
				<?php
			} 
			else {
				
				echo "Invalid Username and Password";
			}
		}
	}
	


?>