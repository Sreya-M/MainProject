
<?php 
session_start();
include 'connection.php';
if (isset($_SESSION['id'])) {


$ri = $_SESSION['id'];

 
//$did=$_POST['did'];
//$did=$_GET['uid'];

$did=$_POST['didd'];
$date=$_POST['time'];

echo $name,$date;

               
                $query = "select * from tbl_doctor where doc_id='$did'";
                $res = mysqli_query($conn, $query);
                $r = mysqli_fetch_array($res);
                $tkn=$r["tkn"]; 
		  
	
		$sql1="INSERT INTO `tbl_docsch`(`doc_id`, `slot_id`, `date`,`tkns` , `status`) 
         VALUES ('$did','1','$date',$tkn,1)";
         
       if(mysqli_query($conn,$sql1))
	   {
		   if(headers_sent()){
		   die('<script type="text/javascript">window.location.href="hosviewdoc.php?e=1"</script>');
		   }
		   else {
		   header("location:hosviewdoc.php?e=1");
		   die();
		   }
	   }
	
  
 
  else {

	echo "Error: " . $sql1 . "<br>" . mysqli_error($conn);
  }
}

  mysqli_close($conn);
?>
