<?php
session_start();
include 'connection.php';
if (isset($_SESSION['id'])) {
?>

<?php
        $ri = $_SESSION['id'];
        
        $query = "select * from tbl_hospital where login_id='$ri'";
        $res = mysqli_query($conn, $query);
        $r = mysqli_fetch_array($res);
        ?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Covid Preventocity</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="assets/img/icon.jpg" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="assets/vendor/remixicon/remixicon.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">

  <!-- =======================================================
  * Template Name: OnePage - v4.7.0
  * Template URL: https://bootstrapmade.com/onepage-multipurpose-bootstrap-template/
  * Author: BootstrapMade.com
  * License: https://bootstrapmade.com/license/
  ======================================================== -->
</head>

<body>

  <!-- ======= Header ======= -->
  <header id="header" class="fixed-top">
    <div class="container d-flex align-items-center justify-content-between">

      <h1 class="logo"><a href="hospitalhome.php">Covid Preventocity</a></h1>
      <!-- Uncomment below if you prefer to use an image logo -->
      <!-- <a href="index.html" class="logo"><img src="assets/img/logo.png" alt="" class="img-fluid"></a>-->

      <nav id="navbar" class="navbar">
        <ul>
          <li><a class="nav-link scrollto active" href="hospitalhome.php">Home</a></li>
         
          
         
          <li class="dropdown"><a href="#"><span> Appoinments</span> <i class="bi bi-chevron-down"></i></a>
            <ul>
              <li><a href="hosappoinmntphy.php">Physicians</a></li>
              <li><a href="hosappoinmntpsy.php">Psychologist</a></li></ul></li>

         <!--  <li><a class="nav-link scrollto" href="sss.php">Covid Test</a></li>
           <li><a class="nav-link scrollto" href="#pricing">Pricing</a></li>-->
           <li><a class="nav-link scrollto" href="patients.php">Covid Patients</a></li>
           <li class="dropdown"><a href="#"><span> Doctor</span> <i class="bi bi-chevron-down"></i></a>
            <ul>
              <li><a href="hosviewdoc.php">Doctor List</a></li>
              <li><a href="hosdocschdate.php">Doctor Schedule</a></li></ul></li>
           <!-- <li><a class="nav-link scrollto" href="hosviewdoc.php">Doctor</a></li>
           <li><a class="nav-link scrollto" href="hosdocschdate.php">Doctor Sched</a></li> -->

          <li class="dropdown"><a href="#"><span> Services</span> <i class="bi bi-chevron-down"></i></a>
            <ul>
              <li><a href="hosvacc.php">Vaccine</a></li>
              <li><a href="hospanch.php">Panchayath</a></li>

              <li class="dropdown"><a href="#"><span>Covid Test</span> <i class="bi bi-chevron-right"></i></a>
                <ul>
                  <li><a href="hosctant.php">Antigen</a></li>
                  <li><a href="hosctrt.php">RTPCR</a></li>
                  

                </ul>
              </li>
              
            </ul>
          </li>
          <li class="nav-item dropdown pe-3">

          <a class="nav-link nav-profile d-flex align-items-center pe-0" href="#" data-bs-toggle="dropdown">
            <!-- <img src="assets/img/n.png" alt="Profile" class="rounded-circle"> -->
            <span><b><?php echo $r['name']; ?></b></span><i  class="bi bi-chevron-down"></i>
          </a><!-- End Profile Iamge Icon -->

          <ul>
            <li>
              
              <span><a href="hosprofile.php"> Profile</a></span>
            </li>
           </ul>
          <li><a class="getstarted scrollto" href="logout.php">LOGOUT</a></li>
        </ul>
        <i class="bi bi-list mobile-nav-toggle"></i>
      </nav><!-- .navbar -->

    </div>
  </header><!-- End Header -->


      

      <main id="main">

      

       <section class="section profile">
      <div class="row">
        <div class="col-xl-4">

          <div class="card">
            <div class="card-body profile-card pt-4 d-flex flex-column align-items-center">

              
              <h2><?php echo $r['name']; ?></h2>
              <h3>Hospital</h3>
              
            </div>
          </div>

        </div>

        <div class="col-xl-8">

          <div class="card">
            <div class="card-body pt-3">
              <!-- Bordered Tabs -->
              <ul class="nav nav-tabs nav-tabs-bordered">

                <li class="nav-item">
                  <button class="nav-link active" data-bs-toggle="tab" data-bs-target="#profile-overview">Overview</button>
                </li>
                <!-- <li class="nav-item">
                  <button class="nav-link" data-bs-toggle="tab" data-bs-target="#profile-edit">Edit Profile</button>
                </li> -->

               

               
              </ul>
              <div class="tab-content pt-2">

                <div class="tab-pane fade show active profile-overview" id="profile-overview">
                 
                  <h5 class="card-title">Profile Details</h5>

                  <div class="row">
                    <div class="col-lg-3 col-md-4 label ">Name</div>
                    <div class="col-lg-9 col-md-8"><?php echo $r['name']; ?></div>
                  </div>

                  

                  <div class="row">
                    <div class="col-lg-3 col-md-4 label">Phone</div>
                    <div class="col-lg-9 col-md-8"><?php echo $r['Phone']; ?></div>
                  </div>

                  <div class="row">
                    <div class="col-lg-3 col-md-4 label">Email</div>
                    <div class="col-lg-9 col-md-8"><?php echo $r['email']; ?></div>
                  </div>

                </div>

              <!-- <div class="tab-pane fade profile-edit pt-3" id="profile-edit">

                  
                  <form name="form" id="form" method="POST" enctype="multipart/form-data" action=" ">
                  <?php

                        $pdetails = mysqli_query($conn, "select * from tbl_hospital where login_id=$ri");
                        $pd = mysqli_fetch_array($pdetails); ?>

                        <input type="hidden" name="id" value=" <?php echo $pd['h_id']; ?>" />        
                    

                    <div class="row mb-3">
                      <label for="fullName" class="col-md-4 col-lg-3 col-form-label"> Name</label>
                      <div class="col-md-8 col-lg-9">
                        <input  type="text" class="form-control" name="pnname" id="name" value="<?php echo $r['name']; ?>">
                      </div>
                    </div>
         

                    <div class="row mb-3">
                      <label for="Phone" class="col-md-4 col-lg-3 col-form-label">Phone</label>
                      <div class="col-md-8 col-lg-9">
                        <input type="text" class="form-control" id="mobile" name="mobile" value="<?php echo $r['Phone']; ?>">
                      </div>
                    </div>

                    <div class="row mb-3">
                      <label for="Email" class="col-md-4 col-lg-3 col-form-label">Email</label>
                      <div class="col-md-8 col-lg-9">
                        <input type="email" class="form-control" id="emailid" name="emailid" value="<?php echo $r['email']; ?>">
                      </div>
                    </div>

                    
                    <div class="text-center">
                      <button type="submit" value="submit" name="submit" class="btn btn-primary">Save Changes</button>
                    </div>
                  </form>End Profile Edit Form -->

                </div>

                
                </div>

              </div><!-- End Bordered Tabs -->

            </div>
          </div>

        </div>
      </div>
    </section>
      </main><!-- End #main -->

      <!-- ======= Footer ======= -->
      <footer id="footer">

        <div class="footer-top">
          <div class="container">
            <div class="row">

              <div class="col-lg-3 col-md-6 footer-contact">
                <h3>Covid Preventocity</h3>
                <p>
                  MCA <br>
                  Amal Jyothi<br>
                  Kanjirappally <br><br>
                  <strong>Phone:</strong> 123333<br>
                  <strong>Email:</strong> info@example.com<br>
                </p>
              </div>
            </div>
          </div>
        </div>
      </footer><!-- End Footer -->

      <div id="preloader"></div>
      <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

      <!-- Vendor JS Files -->
      <script src="assets/vendor/purecounter/purecounter.js"></script>
      <script src="assets/vendor/aos/aos.js"></script>
      <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
      <script src="assets/vendor/glightbox/js/glightbox.min.js"></script>
      <script src="assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
      <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>
      <script src="assets/vendor/php-email-form/validate.js"></script>

      <!-- Template Main JS File -->
      <script src="assets/js/main.js"></script>

</body>

</html>
<?php
} else {
  if (headers_sent()) {
    die('<script type="text/javascript">window.location.href="login.php?e=1"</script>');
  } else {
    header("location:login.php?e=1");
    die();
  }
}
?>    