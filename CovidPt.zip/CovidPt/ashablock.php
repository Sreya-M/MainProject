<?php
	$ash_id=$_GET['uid'];
	include('connection.php');


	
	mysqli_query($conn,"update `tbl_ashaworker` set as_status=0 where as_id='$ash_id'");
	header('location:ashaworker.php');
?>