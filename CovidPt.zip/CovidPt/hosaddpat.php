<?php
session_start();
include 'connection.php';

if (isset($_SESSION['id'])) {
?>

<?php
        $ri = $_SESSION['id'];
        
        $query = "select * from tbl_hospital where login_id='$ri'";
        $res = mysqli_query($conn, $query);
        $r = mysqli_fetch_array($res);
        ?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Covid Preventocity</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="assets/img/icon.jpg" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="assets/vendor/remixicon/remixicon.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">

  <!-- =======================================================
  * Template Name: OnePage - v4.7.0
  * Template URL: https://bootstrapmade.com/onepage-multipurpose-bootstrap-template/
  * Author: BootstrapMade.com
  * License: https://bootstrapmade.com/license/
  ======================================================== -->
</head>

<body>

  <!-- ======= Header ======= -->
  <header id="header" class="fixed-top">
    <div class="container d-flex align-items-center justify-content-between">

      <h1 class="logo"><a href="hospitalhome.php">Covid Preventocity</a></h1>
      <!-- Uncomment below if you prefer to use an image logo -->
      <!-- <a href="index.html" class="logo"><img src="assets/img/logo.png" alt="" class="img-fluid"></a>-->
      <nav id="navbar" class="navbar">
        <ul>
          <li><a class="nav-link scrollto active" href="hospitalhome.php">Home</a></li>
         
          
         
          <li class="dropdown"><a href="#"><span> Appoinments</span> <i class="bi bi-chevron-down"></i></a>
            <ul>
              <li><a href="hosappoinmntphy.php">Physicians</a></li>
              <li><a href="hosappoinmntpsy.php">Psychologist</a></li></ul></li>

         <!--  <li><a class="nav-link scrollto" href="sss.php">Covid Test</a></li>
           <li><a class="nav-link scrollto" href="#pricing">Pricing</a></li>-->
           <li><a class="nav-link scrollto" href="patients.php">Covid Patients</a></li>
           <li class="dropdown"><a href="#"><span> Doctor</span> <i class="bi bi-chevron-down"></i></a>
            <ul>
              <li><a href="hosviewdoc.php">Doctor List</a></li>
              <li><a href="hosdocschdate.php">Doctor Schedule</a></li></ul></li>
           <!-- <li><a class="nav-link scrollto" href="hosviewdoc.php">Doctor</a></li>
           <li><a class="nav-link scrollto" href="hosdocschdate.php">Doctor Sched</a></li> -->

          <li class="dropdown"><a href="#"><span> Services</span> <i class="bi bi-chevron-down"></i></a>
            <ul>
              <li><a href="hosvacc.php">Vaccine</a></li>
              <li><a href="hospanch.php">Panchayath</a></li>

              <li class="dropdown"><a href="#"><span>Covid Test</span> <i class="bi bi-chevron-right"></i></a>
                <ul>
                  <li><a href="hosctant.php">Antigen</a></li>
                  <li><a href="hosctrt.php">RTPCR</a></li>
                  

                </ul>
              </li>
              
            </ul>
          </li>
          <li class="nav-item dropdown pe-3">

          <a class="nav-link nav-profile d-flex align-items-center pe-0" href="#" data-bs-toggle="dropdown">
            <img src="assets/img/n.png" alt="Profile" class="rounded-circle">
            <span><b><?php echo $r['name']; ?></b></span><i  class="bi bi-chevron-down"></i>
          </a><!-- End Profile Iamge Icon -->

          <ul>
            <li>
              
              <span><a href="hosprofile.php"> Profile</a></span>
            </li>
           </ul>
          <li><a class="getstarted scrollto" href="logout.php">LOGOUT</a></li>
        </ul>
        <i class="bi bi-list mobile-nav-toggle"></i>
      </nav><!-- .navbar -->


    </div>
  </header><!-- End Header -->

  


      

      <main id="main">


      <section class="breadcrumbs">
      <div class="container">

        <div class="d-flex justify-content-between align-items-center">
          <h2>Add Patients</h2>
          <ol>
            <li><a href="hospitalhome.php">Home</a></li>
            <li>Covid Patients</li>
          </ol>
        </div>

      </div>
    </section>
        <!-- ======= About Section ======= -->
        <section id="about" class="about">
          <div class="container" data-aos="fade-up">
            
            <div class="section-title">
              
              <p> </p>
            </div>
             

            <section class="section dashboard">
      <div class="row">

      <div class="col-lg-12">

         
          
                
      <form class="row g-3" name="form" id="form" method="POST" action="hosaddpatact.php">
                
                
                <div class="col-md-12">
                  <div class="form-floating">
                    <input type="text" class="form-control" name="name" id="name" placeholder="Name"  required onchange=valname();>
                    <label for="floatingName">Patients Name</label>
                  </div>
                </div>
                <span id="msg1" style="color:red;"></span>
                              <script>
                             
                    function Validate() 
                    {
                        var val = document.getElementById('name').value;
                    
                        if (!val.match(/^[A-Z][A-Za-z\ ]{2,}$/)) 
                        {
                            document.getElementById('msg1').innerHTML="Start with a Capital letter & Only alphabets  are allowed!!";
                                        document.getElementById('name').value = "";
                            return false;
                        }
                    document.getElementById('msg1').innerHTML=" ";
                        return true;
                    }
                    </script>
                
                
                <div class="col-md-6">
                  <div class="form-floating">
                    <input type="text" class="form-control" id="age" name="age" placeholder="intl" required onchange=valage();>
                    <label for="floatingEmail">Age</label>
                  </div>
                </div>
                <span id="msg2" style="color:red;"></span>
                              <script>
                             
                    function valage() 
                    {
                        var val = document.getElementById('age').value;
                    
                        if (!val.match(/^[1-9][0-9]{0,}$/)) 
                        {
                            document.getElementById('msg2').innerHTML=" Only numbers  are allowed!!";
                                        document.getElementById('age').value = "";
                            return false;
                        }
                    document.getElementById('msg2').innerHTML=" ";
                        return true;
                    }
                    </script>
                <div class="form-group">
                       Panchayath Name:
							<!--<input type="text" class="form-input" name="panch" id="panch" placeholder="Your Panchayath"/> -->
							<select name='panch' class="form-input" id='panch' placeholder="Your panchayath" required >
								<option> </option>

								<?php
								$conn = mysqli_connect('localhost', 'root', '', 'covidpt');
								$query = mysqli_query($conn, "select * from tbl_panchayath");
								while ($row = mysqli_fetch_array($query)) {
								?>
									<option value="<?php echo $row['panch_id']; ?>"><?php echo $row['panch_name']; ?> </option>
								<?php
								}
								?>

							</select>
						</div>

                <div class="col-md-6">
                  <div class="form-floating">
                    <input type="text" class="form-control" name="mobile" id="mobile" placeholder="avl" required onchange="Validat();">
                    <label for="floatingZip">Contact</label>
                  </div>
                </div>
                <span id="msg4" style="color:red;"></span>
			
            <script>
      function Validat() 
      {
      var val = document.getElementById('mobile').value;
      
      if (!val.match(/^[789][1-9]{9}$/))
      {
      document.getElementById('msg4').innerHTML="Only Numbers are allowed and must contain 10 number";
      
      
      document.getElementById('mobile').value = "";
      return false;
      }
      document.getElementById('msg4').innerHTML=" ";
      return true;
      }
      </script>
                <div class="text-center">
                  <button type="submit" name="submit" id="submit" value='Submit' class="btn btn-primary">Submit</button>
                  <button type="reset" class="btn btn-secondary">Reset</button>
                </div>
              </form>
          

      </main><!-- End #main -->

      <!-- ======= Footer ======= -->
      <footer id="footer">

        <div class="footer-top">
          <div class="container">
            <div class="row">

              <div class="col-lg-3 col-md-6 footer-contact">
                <h3>Covid Preventocity</h3>
                <p>
                  MCA <br>
                  Amal Jyothi<br>
                  Kanjirappally <br><br>
                  <strong>Phone:</strong> 123333<br>
                  <strong>Email:</strong> info@example.com<br>
                </p>
              </div>
            </div>
          </div>
        </div>
      </footer><!-- End Footer -->

      <div id="preloader"></div>
      <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

      <!-- Vendor JS Files -->
      <script src="assets/vendor/purecounter/purecounter.js"></script>
      <script src="assets/vendor/aos/aos.js"></script>
      <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
      <script src="assets/vendor/glightbox/js/glightbox.min.js"></script>
      <script src="assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
      <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>
      <script src="assets/vendor/php-email-form/validate.js"></script>

      <!-- Template Main JS File -->
      <script src="assets/js/main.js"></script>

</body>

</html>
<?php
} else {
  if (headers_sent()) {
    die('<script type="text/javascript">window.location.href="login.php?e=1"</script>');
  } else {
    header("location:login.php?e=1");
    die();
  }
}
?>    