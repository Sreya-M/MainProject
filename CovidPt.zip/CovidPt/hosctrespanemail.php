
<?php
//Import PHPMailer classes into the global namespace
//These must be at the top of your script, not inside a function
use PHPMailer\PHPMailer\PHPMailer; 
use PHPMailer\PHPMailer\Exception; 
//  $eemail=$_GET['email'];
 $rid=$_GET['eid'];
require 'src\Exception.php'; 
require 'src\PHPMailer.php'; 
require 'src\SMTP.php'; 
include('connection.php');

$sql=mysqli_query($conn,"SELECT * FROM `tbl_posthos` WHERE `pt_id`='$rid'");
$rows=mysqli_fetch_array($sql);
$num=$rows['ward_num'];
$name=$rows['pt_name'];
$mob=$rows['pt_mob'];
$date=$rows['cdate'];
$hid=$rows['h_id'];
$panch=$rows['panch_id'];
$query1 = "select * from tbl_hospital where h_id='$hid'";
$res1 = mysqli_query($conn, $query1);
$r1 = mysqli_fetch_array($res1);
$hname=$r1['name'];
$query = "select * from tbl_panchayath where panch_id='$panch'";
$res = mysqli_query($conn, $query);
$r = mysqli_fetch_array($res);
$email=$r['panch_email'];

//Create an instance; passing `true` enables exceptions
$mail = new PHPMailer(true);

try {
    //Server settings
    //$mail->SMTPDebug = SMTP::DEBUG_SERVER;                      //Enable verbose debug output
    $mail->isSMTP();                                            //Send using SMTP
    $mail->Host       = 'smtp.gmail.com';                     //Set the SMTP server to send through
    $mail->SMTPAuth   = true;                                   //Enable SMTP authentication
    $mail->Username   = 'covidpreventocity@gmail.com';                     //SMTP username
    $mail->Password   = 'gkvfpkhmqozsdund';                               //SMTP password
    $mail->SMTPSecure = 'tls';            //Enable implicit TLS encryption
    $mail->Port       = 587;                                    //TCP port to connect to; use 587 if you have set `SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS`

    //Recipients
    $mail->setFrom('covidpreventocity@gmail.com', 'Covid Preventocity');
    $mail->addAddress($email);     //Add a recipient
  //  $mail->addAddress('ellen@example.com');               //Name is optional
  //  $mail->addReplyTo('info@example.com', 'Information');
  //  $mail->addCC('cc@example.com');
   // $mail->addBCC('bcc@example.com');

    //Attachments
   /// $mail->addAttachment('/var/tmp/file.tar.gz');         //Add attachments
    //$mail->addAttachment('/tmp/image.jpg', 'new.jpg');    //Optional name

    //Content
    $mail->isHTML(true);                                  //Set email format to HTML
    $mail->Subject = 'Covid Test Result-Positives';
    $mail->Body    = 'Name : '.$name.' <br>  Ward Number: '.$num.' <br> Contact Number: '.$mob.'<br> Date: '.$date.' <br> Hospital Name: '.$hname;
    $mail->AltBody = 'Result From:'.$hname;

    $mail->send();
    echo "<script>alert('Message has been Sent');window.location.href='hospitalhome.php';</script>";
   
} catch (Exception $e) {
    echo $email;
    echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
}