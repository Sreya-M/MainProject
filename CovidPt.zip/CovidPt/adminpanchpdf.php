<?php
session_start();
include 'connection.php';

if (isset($_SESSION['id'])) 
{    

//    $pid=$_GET['uid'];
//     $ri=$_SESSION['id'];


         $result=mysqli_query($conn,"SELECT * from tbl_panchayath") or die(mysqli_error($con));
        
                 
                 if ($result->num_rows > 0) {
                   // output data of each row
                   while($row = $result->fetch_assoc()) {
                     

// $result=mysqli_query($con,"SELECT first_name,last_name,age,gender,parent_name,paddress,caddress,email,phone_no,license_type,date_of_issue,expiriry_date,blood FROM `tbl_drivinglicense` where driving_id=$driving_id") or die(mysqli_error($con));


include('pdf_table.php');
$pdf = new PDF_MC_TABLE();
$pdf->AddPage();
$pdf->SetFont('Arial','B',15);	
$pdf->Cell(176, 5, 'Result Details', 0, 0, 'C');
  $pdf->Ln();
  $pdf->Ln();
  $pdf->Ln();	
$row=mysqli_fetch_array($result);
$pdf->SetFont('Arial','',12);	
$pdf->Multicell(80,12,'Panchayath Name : '. $row['panch_name'],1);
$pdf->Multicell(80,12,'Panchayath President Name : '. $row['panch_president_name'],1);
$pdf->Multicell(80,12,'Number of Days : '. $row['num_wards'],1);



$pdf->Output();

                   }
                }

}
?>