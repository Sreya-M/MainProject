<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta http-equiv="X-UA-Compatible" content="ie=edge">
	<title>Covid Preventocity</title>

	<!-- Font Icon -->
	<link rel="stylesheet" href="reassets/fonts/material-icon/css/material-design-iconic-font.min.css">

	<!-- Main css -->
	<link rel="stylesheet" href="reassets/css/style.css">

	<style>
   .button2 {
  background-color: white; 
  color: black; 
  border: 2px solid #008CBA;
  width: 100px;
  height: 30px;
}

.button2:hover {
  background-color: #008CBA;
  color: white;
}</style>
</head>

<body>
<a href="login.php"><button class="button button2">Back</button></a>
	<div class="main">

		<section class="signup">

			<div class="container">
				<div class="signup-content">
					<form method="POST" action="reginsert1.php" id="form2" name="form2" autocomplete="off" class="signup-form">
						<h2 class="form-title">Hospital Registration</h2>

                        <div class="form-group">
							Hospital Name:
							<input type="text" class="form-input" name="name" id="name" placeholder="Your Name" required onchange="Validate();" />
						</div>
                       
                            <span id="msg1" style="color:red;"></span>
                              <script>
                             
                    function Validate() 
                    {
                        var val = document.getElementById('name').value;
                    
                        if (!val.match(/^[A-Z][A-Za-z\ ]{2,}$/)) 
                        {
                            document.getElementById('msg1').innerHTML="Start with a Capital letter & Only alphabets  are allowed!!";
                                        document.getElementById('name').value = "";
                            return false;
                        }
                    document.getElementById('msg1').innerHTML=" ";
                        return true;
                    }
                    </script>
                

			
					<div class="form-group">
                        Hospital Panchayath Name:
							<!--<input type="text" class="form-input" name="panch" id="panch" placeholder="Your Panchayath"/> -->
							<select name='panch' class="form-input" id='panch' placeholder="Your panchayath" required >
								<option> </option>

								<?php
								$conn = mysqli_connect('localhost', 'root', '', 'covidpt');
								$query = mysqli_query($conn, "select * from tbl_panchayath");
								while ($row = mysqli_fetch_array($query)) {
								?>
									<option value="<?php echo $row['panch_id']; ?>"><?php echo $row['panch_name']; ?> </option>
								<?php
								}
								?>

							</select>
						</div>
						<div class="form-group">
                        Hospital License Number:
							<input type="text"  class="form-input" name="lic" id="lic" placeholder="License Number" required onchange="Validat();" />
						</div>
                        <span id="msg9" style="color:red;"></span>
			
                        <script>
function Validat() 
{
    var val = document.getElementById('lic').value;

    if (!val.match(/^[1-9][1-9]{9}$/))
    {
        document.getElementById('msg9').innerHTML="Only Numbers are allowed and must contain 10 number";
	
		
		            document.getElementById('lic').value = "";
        return false;
    }
document.getElementById('msg9').innerHTML=" ";
    return true;
}
</script>
						<div class="form-group">
                        Hospital Mobile Number:
							<input type="text"  class="form-input" name="mobile" id="mobile" placeholder="Your Mobile Number" required onchange="Validat();" />
						</div>
                        <span id="msg4" style="color:red;"></span>
			
                        <script>
function Validat() 
{
    var val = document.getElementById('mobile').value;

    if (!val.match(/^[789][1-9]{9}$/))
    {
        document.getElementById('msg4').innerHTML="Only Numbers are allowed and must contain 10 number";
	
		
		            document.getElementById('mobile').value = "";
        return false;
    }
document.getElementById('msg4').innerHTML=" ";
    return true;
}
</script>
                        
						<div class="form-group">
                        Hospital Email:
							<input type="email" class="form-input" name="emailid" id="emailid" placeholder="Your Email"  required onchange="Validata();" />
						</div>
                        <span id="msg5" style="color:red;"></span>
<script>		
function Validata() 
{
    var val = document.getElementById('emailid').value;

    if (!val.match(/^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/)) 
    {
        document.getElementById('msg5').innerHTML="Enter a Valid Email";
		
		     document.getElementById('emailid').value = "";
        return false;
    }
document.getElementById('msg5').innerHTML=" ";
    return true;
}

		</script>
						<div class="form-group">
							UserName:
							<input type="text" class="form-input" name="username" id="username" placeholder="Your UserName"  onchange="Validate1();"/>
						</div>
                        <span id="msg2" style="color:red;"></span>
                              <script>
                             
                    function Validate1() 
                    {
                        var val = document.getElementById('username').value;
                    
                        if (!val.match(/^[A-Z][A-Za-z0-9]{5,}/)) 
                        {
                            document.getElementById('msg2').innerHTML="Start with a Capital letter & Only alphabets and Numbers  are allowed...Minimum 6 characters required!!";
                                        document.getElementById('username').value = "";
                            return false;
                        }
                    document.getElementById('msg2').innerHTML=" ";
                        return true;
                    }
                    </script>

						<div class="form-group">
							Password:
							<input type="password" class="form-input" name="passwd" id="passwd" placeholder="Password"  required onchange="Validp();"/>
							<!--<span toggle="#password" class="zmdi zmdi-eye field-icon toggle-password"></span>-->
						</div>
                        <span id="msg6" style="color:red;"></span>
<script>		
function Validp() 
{
    var val = document.getElementById('passwd').value;

    if (!val.match(/^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[#?!@$%^&*-])/)) 
    {
        document.getElementById('msg6').innerHTML="Upper case, Lower case, Special character and Numeric number are required in Password filed";
		
		     document.getElementById('passwd').value = "";
        return false;
    }
document.getElementById('msg6').innerHTML=" ";
    return true;
}
		</script>
        				<div class="form-group">
							Confirm Password:
							<input type="password" class="form-input" name="cpasswd" id="cpasswd" placeholder="Repeat your password"  required onchange="check();"/>
						</div>
                        <span id="msg7" style="color:red;"></span>
<script>
function check()
{
                            var pas1=document.getElementById("passwd");
							  var pas2=document.getElementById("cpasswd");
							
							  if(pas1.value=="")
	{
		document.getElementById('msg7').innerHTML="Password can't be null!!";
		pas1.focus();
		return false;
	}
	if(pas2.value=="")
	{
		document.getElementById('msg7').innerHTML="Please confirm password!!";
		pass2.focus();
		return false;
	}
	if(pas1.value!=pas2.value)
	{
		document.getElementById('msg7').innerHTML="Passwords does not match!!";
		pas1.focus();
		return false;
	}
     document.getElementById('msg7').innerHTML=" "; 
	return true;
	
}
	</script>
						<div class="form-group">
							<input type="checkbox" name="agree-term" id="agree-term" class="agree-term" />
							
						</div>
						<div class="form-group">
							<input type="submit" name="submit" id="submit"  value='Submit' class="form-submit" />
						</div>
					</form>
					<p class="loginhere">
						Have already an account ? <a href="login.php" class="loginhere-link">Login here</a>
					</p>
				</div>
			</div>
		</section>

	</div>

	<!-- JS -->
	<script src="reassets/vendor/jquery/jquery.min.js"></script>
	<script src="reassets/js/main.js"></script>
</body><!-- This templates was made by Colorlib (https://colorlib.com) -->

</html>