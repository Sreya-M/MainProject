<?php
	$r_id=$_GET['uid'];
	include('connection.php');

    // $query = "select * from tbl_doctor where doc_id='$r_id'";
    // $res = mysqli_query($conn, $query);
    // $r = mysqli_fetch_array($res);
     
    #echo $pid;

	
	mysqli_query($conn,"update `tbl_doctor` set status='Absent' where doc_id='$r_id'");
	header('location:hosviewdoc.php');
?>