

<?php 
session_start();
include 'connection.php';
if (isset($_SESSION['id'])) {


$ri = $_SESSION['id'];
$vacid=$_POST['vid'];
$vacnum=$_POST['num'];
$vdate=$_POST['vdate'];

echo $vacid;

$query = "select * from tbl_hospital where login_id='$ri'";
$res = mysqli_query($conn, $query);
$r = mysqli_fetch_array($res);
$pid=$r["h_id"];
$panchid=$r["panch_id"];




		  
				
		$sql1="INSERT INTO `tbl_vaccreq`( `h_id`, `panch_id`, `vac_id`, `vac_num`,`vdate`, `status`) 
        VALUES ('$pid','$panchid','$vacid','$vacnum',CURRENT_DATE,'Pending')";
       if(mysqli_query($conn,$sql1))
	   {
		   if(headers_sent()){
		   die('<script type="text/javascript">window.location.href="hosvaccreqst.php?e=1"</script>');
		   }
		   else {
		   header("location:hosvaccreqst.php?e=1");
		   die();
		   }
	   }
	
  
 
  else {

	echo "Error: " . $sql1 . "<br>" . mysqli_error($conn);
  }
}
  mysqli_close($conn);
?>
