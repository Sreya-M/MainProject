<?php
	
    
	include('connection.php');

    // $query = "select * from tbl_doctor where doc_id='$r_id'";
    // $res = mysqli_query($conn, $query);
    // $r = mysqli_fetch_array($res);
    $r_id=$_GET['uid'];
    $pid=0;

	
	mysqli_query($conn,"update `tbl_docsch` set status='$pid' where doc_id='$r_id'");
	header('location:hosviewdoc.php');
?>