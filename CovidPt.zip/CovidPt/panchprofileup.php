

<?php


include 'connection.php';
session_start();
$a=$_SESSION['id'];
echo $a;
if(isset($_POST['submit']))
{
    $a=$_SESSION['id'];
    echo $a;
    $name=$_POST['namej'];
    $pname=$_POST['pname'];
    $mobile=$_POST['mobile'];
    $emailid=$_POST['emailid'];
    $numw=$_POST['numw'];
  /*  echo $name;echo $pname;echo $mobile;echo $emailid;echo $numw;

		$sql="UPDATE `tbl_panchayath` SET `panch_name`='$name',`panch_president_name`='$pname',`panch_mobile`='$mobile',`panch_email`='$emailid',`num_wards`='$numw' WHERE `panch_id`='$a'";
        $edit=mysqli_query($conn,$sql);
	
	header("location:panchprofile.php?uid=$_SESSION[id]");*/
}
?>
