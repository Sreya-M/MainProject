<?php
	$r_id=$_GET['eid'];
	include('connection.php');
	

	$date=date("y-m-d");	 
	mysqli_query($conn,"UPDATE `tbl_wards` SET `con_status`='Inactive' WHERE  ward_id='$r_id'");
	mysqli_query($conn,"UPDATE `tbl_containmentzone` SET `cont_status`='Inactive',`cont_end_date`='$date' WHERE ward_id='$r_id'");
	header('location:viewward.php');
?>