<?php 
session_start();

include('connection.php');
include('pdf_table.php');
if(isset($_POST['generatepdf']))
{
    $pid=$_POST['rid'];
    $query = "select * from tbl_panchayath where panch_id='$pid'";
                $res = mysqli_query($conn, $query);
                $r = mysqli_fetch_array($res);
                
               

  $result = mysqli_query($conn,"SELECT tbl_panchvacc.*,tbl_vacc.* from tbl_panchvacc join tbl_vacc where tbl_panchvacc.vac_id=tbl_vacc.vac_id AND tbl_panchvacc.panch_id='$pid'") or die(mysqli_error($con));
  $pdf = new PDF_MC_TABLE();
  $pdf->AddPage();

  $pdf->SetFont('Arial', 'B', 15);
  $pdf->Cell(176, 5, 'Vaccine Details', 0, 0, 'C');
  $pdf->Ln();
  $pdf->Ln();
  $pdf->Ln();

  $pdf->SetFont('Arial','',10);
  
  $pdf->SetWidths(Array(11,30,30,30,30));

  $pdf->SetLineHeight(5);

  $pdf->SetFont('Arial','B',10);
  $pdf->Multicell(80,12,'Panchayath Name : '. $r['panch_name'],1);
  $pdf->Cell(11,5,"Sl No",1,0);
  $pdf->Cell(30,5,"Vaccine Name",1,0);
  $pdf->Cell(30,5,"Number of Dose",1,0);
  $pdf->Cell(30,5,"Intervel",1,0);
  $pdf->Cell(30,5,"Available",1,0);
  
  $pdf->Ln();
  
  $pdf->SetFont('Arial','',10);	
  $i=1;
  foreach($result as $row) {
    $pdf->Row(Array(
        $i,
		$row['vac_name'],
        $row['numdose'],
		$row['intervel'],
		$row['avail'],
		
	));
	$i++;
  }
  $pdf->Output();
}
?>
