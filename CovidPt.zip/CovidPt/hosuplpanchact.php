
<?php 
session_start();
include 'connection.php';
if (isset($_SESSION['id'])) {

$tesid=$_GET['uid'];

               
                $query = "select * from tbl_cvdtest where ctest_id='$tesid'";
                $res = mysqli_query($conn, $query);
                $r = mysqli_fetch_array($res);
                $pid =$r['panch_id'];
                $hid =$r['hos_id'];
                $wid =$r['ward_id'];
                $cname =$r['tpname'];
                $cmob =$r['ctmobile'];
                $cdate =$r['tdate'];
                
		  
	
		$sql1="INSERT INTO `tbl_posthos`(`panch_id`, `h_id`, `ward_num`, `pt_name`, `pt_mob`,`cdate`) 
    VALUES ('$pid','$hid','$wid','$cname','$cmob','$cdate')";
        echo $sql; 
  //      if(mysqli_query($conn,$sql1))
	//    {
	// 	   if(headers_sent()){
	// 	   die('<script type="text/javascript">window.location.href="hospitalhome.php?e=1"</script>');
	// 	   }
	// 	   else {
	// 	   header("location:hospitalhome.php?e=1");
	// 	   die();
	// 	   }
	//    }
	
  
 
  // else {

	// echo "Error: " . $sql . "<br>" . mysqli_error($conn);
  // }
}
  mysqli_close($conn);
?>
