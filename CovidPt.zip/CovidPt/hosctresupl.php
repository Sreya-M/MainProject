<?php
session_start();
include 'connection.php';
use PHPMailer\PHPMailer\PHPMailer; 
use PHPMailer\PHPMailer\Exception;

if (isset($_SESSION['id'])) {
?>

<?php
        $ri = $_SESSION['id'];
        
        $query = "select * from tbl_hospital where login_id='$ri'";
        $res = mysqli_query($conn, $query);
        $r = mysqli_fetch_array($res);
        ?>
<?php






if(isset($_POST['submit']))
{
    $panch_id=$_GET['uid'];
  
  $res1=$_POST['rest'];

  
  
  
  if(mysqli_query($conn,"UPDATE `tbl_cvdtest` SET `result`='$res1' WHERE ctest_id='$panch_id'"))
  {

               $query1 = "select * from tbl_cvdtest where ctest_id='$panch_id'";
                $res2 = mysqli_query($conn, $query1);
                $r1 = mysqli_fetch_array($res2);
                $query2 = "select * from tbl_panchayath  where panch_id='$panch_id'";
                $res2 = mysqli_query($conn, $query2);
                $r2 = mysqli_fetch_array($res2);
                $lo=$r2['panch_email'];
                $pid =$r1['panch_id'];
                $hid =$r1['hos_id'];
                $wid =$r1['ward_id'];
                $cname =$r1['tpname'];
                $cmob =$r1['ctmobile'];      
                $resl =$r1['result'];      
                $cdate =$r1['tdate'];      
                if($resl=='Positive'){
	             $sql="INSERT INTO `tbl_posthos`(`panch_id`, `h_id`, `ward_num`, `pt_name`, `pt_mob`,`cdate`) 
        VALUES ('$pid','$hid','$wid','$cname','$cmob','$cdate')";
       if(mysqli_query($conn,$sql)){
        $rid=mysqli_insert_id($conn);
        

//Import PHPMailer classes into the global namespace
//These must be at the top of your script, not inside a function
 
//  $eemail=$_GET['email'];
//  $rid=$_GET['eid'];
require 'src\Exception.php'; 
require 'src\PHPMailer.php'; 
require 'src\SMTP.php'; 
include('connection.php');

$sql=mysqli_query($conn,"SELECT * FROM `tbl_posthos` WHERE `pt_id`='$rid'");
$rows=mysqli_fetch_array($sql);
$num=$rows['ward_num'];
$name=$rows['pt_name'];
$mob=$rows['pt_mob'];
$date=$rows['cdate'];
$hid=$rows['h_id'];
$panch=$rows['panch_id'];
$query1 = "select * from tbl_hospital where h_id='$hid'";
$res1 = mysqli_query($conn, $query1);
$r1 = mysqli_fetch_array($res1);
$hname=$r1['name'];
$query = "select * from tbl_panchayath where panch_id='$panch'";
$res = mysqli_query($conn, $query);
$r = mysqli_fetch_array($res);
$email=$r['panch_email'];

//Create an instance; passing `true` enables exceptions
$mail = new PHPMailer(true);

try {
    //Server settings
    //$mail->SMTPDebug = SMTP::DEBUG_SERVER;                      //Enable verbose debug output
    $mail->isSMTP();                                            //Send using SMTP
    $mail->Host       = 'smtp.gmail.com';                     //Set the SMTP server to send through
    $mail->SMTPAuth   = true;                                   //Enable SMTP authentication
    $mail->Username   = 'covidpreventocity@gmail.com';                     //SMTP username
    $mail->Password   = 'gkvfpkhmqozsdund';                               //SMTP password
    $mail->SMTPSecure = 'tls';            //Enable implicit TLS encryption
    $mail->Port       = 587;                                    //TCP port to connect to; use 587 if you have set `SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS`

    //Recipients
    $mail->setFrom('covidpreventocity@gmail.com', 'Covid Preventocity');
    $mail->addAddress($email);     //Add a recipient
  //  $mail->addAddress('ellen@example.com');               //Name is optional
  //  $mail->addReplyTo('info@example.com', 'Information');
  //  $mail->addCC('cc@example.com');
   // $mail->addBCC('bcc@example.com');

    //Attachments
   /// $mail->addAttachment('/var/tmp/file.tar.gz');         //Add attachments
    //$mail->addAttachment('/tmp/image.jpg', 'new.jpg');    //Optional name

    //Content
    $mail->isHTML(true);                                  //Set email format to HTML
    $mail->Subject = 'Covid Test Result-Positives';
    $mail->Body    = 'Name : '.$name.' <br>  Ward Number: '.$num.' <br> Contact Number: '.$mob.'<br> Date: '.$date.' <br> Hospital Name: '.$hname;
    $mail->AltBody = 'Result From:'.$hname;

    $mail->send();
    echo "<script>alert('Message has been Sent');window.location.href='hospitalhome.php';</script>";
   
} catch (Exception $e) {
    echo $email;
    echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
}
       }
  }
    
  }
      //  echo "<script>alert('Updated');</script>";
         header("location: hospitalhome.php");
  
}






?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Covid Preventocity</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="assets/img/icon.jpg" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="assets/vendor/remixicon/remixicon.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">

  <!-- =======================================================
  * Template Name: OnePage - v4.7.0
  * Template URL: https://bootstrapmade.com/onepage-multipurpose-bootstrap-template/
  * Author: BootstrapMade.com
  * License: https://bootstrapmade.com/license/
  ======================================================== -->
</head>

<body>

  <!-- ======= Header ======= -->
  <header id="header" class="fixed-top">
    <div class="container d-flex align-items-center justify-content-between">

      <h1 class="logo"><a href="hospitalhome.php">Covid Preventocity</a></h1>
      <!-- Uncomment below if you prefer to use an image logo -->
      <!-- <a href="index.html" class="logo"><img src="assets/img/logo.png" alt="" class="img-fluid"></a>-->

      <nav id="navbar" class="navbar">
        <ul>
          <li><a class="nav-link scrollto active" href="hospitalhome.php">Home</a></li>
         
          
         
          <li class="dropdown"><a href="#"><span> Appoinments</span> <i class="bi bi-chevron-down"></i></a>
            <ul>
              <li><a href="hosappoinmntphy.php">Physicians</a></li>
              <li><a href="hosappoinmntpsy.php">Psychologist</a></li></ul></li>

         <!--  <li><a class="nav-link scrollto" href="sss.php">Covid Test</a></li>
           <li><a class="nav-link scrollto" href="#pricing">Pricing</a></li>-->
           <li><a class="nav-link scrollto" href="patients.php">Covid Patients</a></li>
           <li class="dropdown"><a href="#"><span> Doctor</span> <i class="bi bi-chevron-down"></i></a>
            <ul>
              <li><a href="hosviewdoc.php">Doctor List</a></li>
              <li><a href="hosdocschdate.php">Doctor Schedule</a></li></ul></li>
           <!-- <li><a class="nav-link scrollto" href="hosviewdoc.php">Doctor</a></li>
           <li><a class="nav-link scrollto" href="hosdocschdate.php">Doctor Sched</a></li> -->

          <li class="dropdown"><a href="#"><span> Services</span> <i class="bi bi-chevron-down"></i></a>
            <ul>
              <li><a href="hosvacc.php">Vaccine</a></li>
              <li><a href="hospanch.php">Panchayath</a></li>

              <li class="dropdown"><a href="#"><span>Covid Test</span> <i class="bi bi-chevron-right"></i></a>
                <ul>
                  <li><a href="hosctant.php">Antigen</a></li>
                  <li><a href="hosctrt.php">RTPCR</a></li>
                  

                </ul>
              </li>
              
            </ul>
          </li>
          <li class="nav-item dropdown pe-3">

          <a class="nav-link nav-profile d-flex align-items-center pe-0" href="#" data-bs-toggle="dropdown">
            <img src="assets/img/n.png" alt="Profile" class="rounded-circle">
            <span><b><?php echo $r['name']; ?></b></span><i  class="bi bi-chevron-down"></i>
          </a><!-- End Profile Iamge Icon -->

          <ul>
            <li>
              
              <span><a href="hosprofile.php"> Profile</a></span>
            </li>
           </ul>
          <li><a class="getstarted scrollto" href="logout.php">LOGOUT</a></li>
        </ul>
        <i class="bi bi-list mobile-nav-toggle"></i>
      </nav><!-- .navbar -->

    </div>
  </header><!-- End Header -->

  


      

      <main id="main">


      <section class="breadcrumbs">
      <div class="container">

        <div class="d-flex justify-content-between align-items-center">
          <h2>Result</h2>
          
        </div>

      </div>
    </section>
        <!-- ======= About Section ======= -->
        <section id="about" class="about">
          <div class="container" data-aos="fade-up">
            
            <div class="section-title">
              
              <p> </p>
            </div>
             

            <section class="section dashboard">
      <div class="row">

      <div class="col-lg-12">

<?php
$panch_id=$_GET['uid'];
$sql="select *from `tbl_cvdtest` where ctest_id='$panch_id'";
    $result=mysqli_query($conn,$sql);
    $row=mysqli_fetch_assoc($result);



?>

      <form class="row g-3" name="form" id="form" method="POST" action="">
                <div class="col-md-12">
                  <label for="inputName5" class="form-label">Name</label>
                  <input type="text" class="form-control" name="name" id="name" readonly value="<?php echo $row['tpname']; ?>">
                </div>
                <div class="col-md-2">
                  <label for="inputEmail5" class="form-label">Adhar</label>
                  <input type="age" class="form-control" name="age" id="age" readonly value="<?php echo $row['adhar']; ?>">
                </div>
                <div class="form-group">
                         CovidTest Result:
							<!--<input type="text" class="form-input" name="panch" id="panch" placeholder="Your Panchayath"/> -->
							<select name='rest' class="form-input" id='ctype' placeholder="Your test" required >
								<option> </option>
							
									<option>Positive</option>
									<option>Negative</option>

							

							</select>
              
                
                 <div class="text-center">
                  <button type="submit" class="btn btn-primary" name="submit" id="submit"  value='Submit'>Submit</button></a>
                  
                </div>
              </form>


      </main><!-- End #main -->

      <!-- ======= Footer ======= -->
      <footer id="footer">

        <div class="footer-top">
          <div class="container">
            <div class="row">

              <div class="col-lg-3 col-md-6 footer-contact">
                <h3>Covid Preventocity</h3>
                <p>
                  MCA <br>
                  Amal Jyothi<br>
                  Kanjirappally <br><br>
                  <strong>Phone:</strong> 123333<br>
                  <strong>Email:</strong> info@example.com<br>
                </p>
              </div>
            </div>
          </div>
        </div>
      </footer><!-- End Footer -->

      <div id="preloader"></div>
      <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

      <!-- Vendor JS Files -->
      <script src="assets/vendor/purecounter/purecounter.js"></script>
      <script src="assets/vendor/aos/aos.js"></script>
      <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
      <script src="assets/vendor/glightbox/js/glightbox.min.js"></script>
      <script src="assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
      <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>
      <script src="assets/vendor/php-email-form/validate.js"></script>

      <!-- Template Main JS File -->
      <script src="assets/js/main.js"></script>

</body>

</html>
<?php
} else {
  if (headers_sent()) {
    die('<script type="text/javascript">window.location.href="login.php?e=1"</script>');
  } else {
    header("location:login.php?e=1");
    die();
  }
}
?>    