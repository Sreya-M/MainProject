
<?php 
session_start();
include 'connection.php';
if (isset($_SESSION['id'])) {


$ri = $_SESSION['id'];
$name=$_POST['name'];
$age=$_POST['age'];
$doc=$_POST['didd'];
$ctype=$_POST['cotype'];
$mob=$_POST['mobile'];




$result="select * from tbl_docsch where `sch_id`='$doc'";
$query = mysqli_query($conn, $result);
$row = mysqli_fetch_array($query);
$count=$row['tkns'];
$coun=$count-1;
$cdate=date("y-m-d");


		  
		$sql2="UPDATE `tbl_docsch` SET `tkns`='$coun' WHERE sch_id='$doc'";	
		$sql1="INSERT INTO `tbl_consultreg`( `sch_id`,`log_id`, `conscat`, `name`, `age`,  `con_type`, `mobile`,`status`,`consult`,`codate`) 
		VALUES ('$doc','$ri','Physician','$name','$age','$ctype','$mob','Pending','Pending','$cdate')";
       if(mysqli_query($conn,$sql1))
	   {

		  if(mysqli_query($conn,$sql2))
		  {
		   if(headers_sent()){
		   die('<script type="text/javascript">window.location.href="userregappmt.php?e=1"</script>');
		   }
		   else {
		   header("location:userregappmt.php?e=1");
		   die();
		   }
		}
	   }

	
  
 
  else {

	echo "Error: " . $sql1 . "<br>" . mysqli_error($conn);
  }
}
  mysqli_close($conn);
?>

