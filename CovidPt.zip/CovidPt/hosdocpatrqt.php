<?php
	$pat_id=$_GET['uid'];
	include('connection.php');

    
    $pa="Accepted";

	
	mysqli_query($conn,"update `tbl_consultreg` set status='$pa' where cons_id='$pat_id'");
	header('location:hospitalhome.php');
?>