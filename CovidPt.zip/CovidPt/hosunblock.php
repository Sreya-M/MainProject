<?php
	$r_id=$_GET['uid'];
	include('connection.php');

    $query = "select * from tbl_hospital where h_id='$r_id'";
    $res = mysqli_query($conn, $query);
    $r = mysqli_fetch_array($res);
    $lid=$r["login_id"]; 
    #echo $pid;

	
	mysqli_query($conn,"update `tbl_login` set status=1 where login_id='$lid'");
	header('location:viewhospital.php');
?>