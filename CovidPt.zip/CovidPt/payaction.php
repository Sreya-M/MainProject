<?php 
session_start();
include 'connection.php';
if (isset($_SESSION['id'])) {

  date_default_timezone_set('Asia/Kolkata');
  $date = date('d-m-y h:i:s');  

  $uid=$_SESSION['id'];
     $l=$_GET['id'];
     $sql = mysqli_query($conn, "SELECT tbl_cvdtest.pstatus,tbl_testtype.tamount 
     FROM tbl_cvdtest JOIN tbl_testtype on tbl_cvdtest.type=tbl_testtype.tety_id AND tbl_cvdtest.ctest_id='$l'");
    while ($r6 = mysqli_fetch_array($sql)) 
    {
        $a=$r6['tamount'];
        $i=$r6['pstatus'];
        //$i=$row['pstatus'];
       
    }

    $sql1="INSERT INTO `tbl_paymnt`(`log_id`, `cvd_id`, `pamount`, `pdate`, `pstatus`) 
    VALUES ('$uid','$l','$a','$date','Paid')";


mysqli_query($conn,$sql1);
    if($i=='Unpaid')
    {
    $sql = mysqli_query($conn, "UPDATE `tbl_cvdtest` SET `pstatus`='Paid' WHERE ctest_id='$l'");
  
      ?>
    <script>
      alert("Paid Successfully");
      </script>
    <?php
     
      header("location:bill.php?id=".$l."");
      
       
    }
    
    
}    

  
?>