

                    <tr>
                    <th><?php echo $key; ?></th>
                    <td><?php echo $value[$days_count]['confirmed'];?> </td>                     
                    
                    <td><?php echo $value[$days_count]['recovered'];?> </td>
                    <td><?php echo $value[$days_count]['deaths'];?> </td>

                    
                   
                     </tr>
                     
                  
                     <?php }  ?>
                   


                     <tr><?php echo $coranalive['statewise'][$i]['state'] . "<br>"  ;?></tr>
  <tr><?php echo $coranalive['statewise'][$i]['confirmed'] . "<br>"  ;?></tr>
  <tr><?php echo $coranalive['statewise'][$i]['active'] . "<br>"  ; ?></tr>
  <tr><?php echo $coranalive['statewise'][$i]['recovered'] . "<br>"  ;?></tr>
  <tr><?php echo $coranalive['statewise'][$i]['deaths'] . "<br>"  ; ?></tr>