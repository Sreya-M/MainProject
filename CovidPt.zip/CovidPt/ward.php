<?php
include('connection.php');
if($_POST['id']){
$id=$_POST['id'];
if($id==0){
	echo "<option>Select City</option>";
}else{
	$sql = mysqli_query($conn,"SELECT * FROM `tbl_wards` WHERE panch_id='$id'");
	while($row = mysqli_fetch_array($sql)){
		echo '<option value="'.$row['ward_id'].'">'.$row['ward_num'].'</option>';
		}
	}
}
?>