
<?php 
session_start();
include 'connection.php';
if (isset($_SESSION['id'])) {


$ri = $_SESSION['id'];

$name=$_POST['vname'];
$nod=$_POST['nod'];
$int=$_POST['int'];
$avl=$_POST['avl'];


                $ri = $_SESSION['id'];
                $query = "select * from tbl_panchayath where login_id='$ri'";
                $res = mysqli_query($conn, $query);
                $r = mysqli_fetch_array($res);
                $pid=$r["panch_id"]; 
		  
		$sql="INSERT INTO `tbl_login`(`username`,`passwd`,`type`,`status`) VALUES('$avl','$int','5','1')";
		if(mysqli_query($conn,$sql))
		{
		
	  
		$result1=mysqli_query($conn,"select * from tbl_login where username='$avl'");
		$row=mysqli_fetch_assoc($result1);
		$lo=$row['login_id'];
		
		$sql1="INSERT INTO `tbl_ashaworker`( `wa_id`, `login_id`, `as_name`, `as_mobile`, `as_email`, `as_status`)
		VALUES ('$nod','$row[login_id]','$name','$int','$avl','1')";
       if(mysqli_query($conn,$sql1))
	   {
		   if(headers_sent()){
		   die('<script type="text/javascript">window.location.href="addashamail.php?eid='.$lo.'"</script>');
		   }
		   else {
		   header("location:addashamail.php?eid=".$lo."");
		   die();
		   }
	   }
	
	}
 
  else {

	echo "Error: " . $sql . "<br>" . mysqli_error($conn);
  }
}
  mysqli_close($conn);
?>
