<?php

$r_id=$_GET['eid'];
$avail=$_GET['vid'];
$need=$_GET['nid'];
$pva=$_GET['pid'];


include('connection.php');

$a='Accepted';

$count=$avail-$need;
mysqli_query($conn,"update `tbl_vaccreq` set status='$a' where req_id='$r_id'");
mysqli_query($conn,"UPDATE `tbl_panchvacc` SET `avail`='$count' WHERE  pvacc_id='$pva'");
 



	header('location:vaccreq.php');

?>
