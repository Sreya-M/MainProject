<?php
	$pat_id=$_GET['uid'];
	include('connection.php');

    
    $pa="Consult Completed";

	
	mysqli_query($conn,"update `tbl_consultreg` set consult='$pa' where cons_id='$pat_id'");
	header('location:hospitalhome.php');
?>