<?php
session_start();
include 'connection.php';
if (isset($_SESSION['id'])) {




   
    $vac_id=$_GET['eid'];
    $sql="select *from `tbl_vaccine` where vac_id='$vac_id'";
   
    $result=mysqli_query($conn,$sql);
    
    $row=mysqli_fetch_assoc($result);

    


    
    

   if(isset($_POST['submit']))
   {
   
     $vac_id=$_GET['eid'];
     $vac_name=$_POST['vname'];
     $numo=$_POST['nod'];
     $inter=$_POST['int'];
     $avail=$_POST['avl'];
     

     
     
     
     mysqli_query($conn,"UPDATE `tbl_vaccine` SET `vac_name`='$vac_name',
     `num_dose`='$numo',`intervel`='$inter',`avail`='$avail' WHERE `vac_id`='$vac_id' ");
     
       
    
          echo "<script>alert('Updated');</script>";
            header("location: vaccdet.php");
     
   }
   
   

  


?>
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Covid Preventocity</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="assets/img/icon.jpg" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="assets/vendor/remixicon/remixicon.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">

  <!-- =======================================================
  * Template Name: OnePage - v4.7.0
  * Template URL: https://bootstrapmade.com/onepage-multipurpose-bootstrap-template/
  * Author: BootstrapMade.com
  * License: https://bootstrapmade.com/license/
  ======================================================== -->


  <script type="text/javascript">
  
  
  
	/*function doSubmit()
	{
		var illegalChars = /\W/; // allow letters, numbers, and underscores
		
		
	  if(document.getElementById('vname').value == "")
		{
			alert("Please Enter vaccine Name");
			document.getElementById("form").vname.focus();
		}
		else if( /[^a-zA-Z ]/.test( document.getElementById('vname').value ) ) 
		{
		   alert('Name is not alphanumeric');
		   document.getElementById("form").vname.focus();
		}
       
        else if(document.getElementById('nod').value == "")
		{
			alert("Please Enter number of dose");
			document.getElementById('form').nod.focus();
		}
		else if(isNaN(document.getElementById('nod').value))
		{
			alert("Number of dose Should Be A Number");
			document.getElementById('form').nod.focus();
		}
    else if(document.getElementById('nod').value.length < 5)
		{
			alert("Invalid dose Number should be less than 5");
			document.getElementById('form').nod.focus();
		} 
		
		else if(document.getElementById('int').value == "")
		{
			alert("Please Enter intervel");
			document.getElementById('form').int.focus();
		}
		else if(isNaN(document.getElementById('int').value))
		{
			alert("Intervel Should Be A Number");
			document.getElementById('form').int.focus();
		}
    else if(document.getElementById('int').value.length < 200)
		{
			alert("Invalid Interval");
			document.getElementById('form').int.focus();
		} 
        else if(document.getElementById('avl').value == "")
		{
			alert("Please Enter Available");
			document.getElementById('form').avl.focus();
		}
		else if(isNaN(document.getElementById('avl').value))
		{
			alert("Availability Should Be A Number");
			document.getElementById('form').avl.focus();
		}
		 
        else
        {
            document.getElementById('form').action = 'addvaccaction.php';
	        document.getElementById('form').submit();
        }
    }*/
   </script>
</head>

<body>

  <!-- ======= Header ======= -->
  <header id="header" class="fixed-top">
    <div class="container d-flex align-items-center justify-content-between">

      <h1 class="logo"><a href="index.html">Covid Preventocity</a></h1>
      <!-- Uncomment below if you prefer to use an image logo -->
      <!-- <a href="index.html" class="logo"><img src="assets/img/logo.png" alt="" class="img-fluid"></a>-->

      <nav id="navbar" class="navbar">
        <ul>
          <li><a class="nav-link scrollto active" href="panchhome.php">Home</a></li>
          <li><a class="nav-link scrollto" href="ashaworker.php">Ashaworker</a></li>
          <li><a class="nav-link scrollto" href="vaccine.php">Vaccine Details</a></li>
          <li><a class="nav-link scrollto" href="panchviewhos.php">Hospitals</a></li>
         

         <!-- <li><a href="#"><span>Wards</span></i></a></li>-->
            
          <!--<li><a class="nav-link scrollto" href="#team">Containment Zones</a></li>
           <li><a class="nav-link scrollto" href="#pricing">Asha </a></li>-->
           <li class="dropdown"><a href="#"><span>Wards</span> <i class="bi bi-chevron-down"></i></a>
            <ul>
              <li><a href="viewward.php">List Ward</a></li>
              <li><a href="zoneview.php">Containment Zone</a></li>
            </ul>
          </li>
          <?php
        $ri = $_SESSION['id'];
        
        $query = "select * from tbl_panchayath where login_id='$ri'";
        $res = mysqli_query($conn, $query);
        $r = mysqli_fetch_array($res);
        ?>
        
          <li class="nav-item dropdown pe-3">

<a class="nav-link nav-profile d-flex align-items-center pe-0" href="#" data-bs-toggle="dropdown">
  <img src="assets/img/favicon.png" alt="Profile" class="rounded-circle">
  <span><b><?php echo $r['panch_name']; ?></b></span><i  class="bi bi-chevron-down"></i>
</a><!-- End Profile Iamge Icon -->

<ul>
<li><a class="nav-link scrollto" href="panchprofile.php">Profile</a></li>
 </ul>
         

          <li><a class="getstarted scrollto" href="logout.php">LOGOUT</a></li>
          

        </ul>
        <i class="bi bi-list mobile-nav-toggle"></i>
      </nav><!-- .navbar -->

    </div>
  </header><!-- End Header -->

  





      <main id="main">
        <!-- ======= About Section ======= -->
        <section id="about" class="about">
          <div class="container" data-aos="fade-up">

            <div class="section-title">
              <h2>Vaccine</h2>
              <p> </p>
            </div>
            <section class="section dashboard">
      <div class="row">

      <div class="col-lg-12">

         
          
           
      <form class="row g-3" name="form" id="form" method="POST">
                
                
                <div class="col-md-12">
                  <div class="form-floating">
                    <input type="text" class="form-control" name="vname" id="vname" value= "<?php echo $row['vac_name']; ?>" placeholder="Name">
                    <label for="floatingName">Vaccine Name</label>
                  </div>
                </div>
             <div class="col-md-6">
                  <div class="form-floating">
                    <input type="text" class="form-control" name="nod" id="nod" value= "<?php echo $row['num_dose']; ?>" placeholder="nod">
                    <label for="floatingZip">Number of dose</label>
                  </div>
                </div>
                
                <div class="col-md-6">
                  <div class="form-floating">
                    <input type="text" class="form-control" id="int" name="int"  value= "<?php echo $row['intervel']; ?>"placeholder="intl">
                    <label for="floatingEmail"> Intervel</label>
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="form-floating">
                    <input type="text" class="form-control" name="avl" id="avl" value= "<?php echo $row['avail']; ?>" placeholder="avl">
                    <label for="floatingZip">Availability</label>
                  </div>
                </div>
                
                <div class="text-center">
                  <button type="submit" name="submit" id="submit"  value='Submit' class="btn btn-primary">Submit</button>
                  <button type="reset" class="btn btn-secondary">Reset</button>
                </div>
              </form>

        
      </div>
    </div>
</section>
          </div>
        </section><!-- End About Section -->
        
        



      </main><!-- End #main -->

      <!-- ======= Footer ======= -->
      <footer id="footer">

        <div class="footer-top">
          <div class="container">
            <div class="row">

              <div class="col-lg-3 col-md-6 footer-contact">
                <h3>Covid Preventocity</h3>
                <p>
                  MCA <br>
                  Amal Jyothi<br>
                  Kanjirappally <br><br>
                  <strong>Phone:</strong> 123333<br>
                  <strong>Email:</strong> info@example.com<br>
                </p>
              </div>
            </div>
          </div>
        </div>
      </footer><!-- End Footer -->

      <div id="preloader"></div>
      <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

      <!-- Vendor JS Files -->
      <script src="assets/vendor/purecounter/purecounter.js"></script>
      <script src="assets/vendor/aos/aos.js"></script>
      <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
      <script src="assets/vendor/glightbox/js/glightbox.min.js"></script>
      <script src="assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
      <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>
      <script src="assets/vendor/php-email-form/validate.js"></script>

      <!-- Template Main JS File -->
      <script src="assets/js/main.js"></script>

</body>

</html>










<?php
} else {
  if (headers_sent()) {
    die('<script type="text/javascript">window.location.href="login.php?e=1"</script>');
  } else {
    header("location:login.php?e=1");
    die();
  }
}
?>    


