<?php 
session_start();

include('connection.php');
include('pdf_table.php');
if(isset($_POST['generatepdf']))
{
    // $eid=$_POST['eid'];
    $pid=$_POST['rid'];
   
  $result = mysqli_query($conn," SELECT
  tbl_containmentzone.zone_id,
  tbl_containmentzone.cont_status,
  tbl_containmentzone.cont_declaredate,tbl_contdet.* ,
  tbl_wards.ward_id,
  tbl_wards.ward_mem_name,tbl_wards.ward_mem_numb,
  tbl_wards.ward_num,tbl_panchayath.panch_name
  FROM tbl_wards
  JOIN tbl_panchayath
  ON tbl_wards.panch_id = tbl_panchayath.panch_id AND tbl_wards.panch_id='$pid'
  JOIN tbl_containmentzone
  ON tbl_containmentzone.ward_id = tbl_wards.ward_id
  JOIN tbl_contdet 
  ON tbl_containmentzone.zone_id=tbl_contdet.zone_id") or die(mysqli_error($con));
  $pdf = new PDF_MC_TABLE();
  $pdf->AddPage();

  $pdf->SetFont('Arial', 'B', 15);
  $pdf->Cell(176, 5, 'ContainmentZone Details', 0, 0, 'C');
  $pdf->Ln();
  $pdf->Ln();
  $pdf->Ln();

  $pdf->SetFont('Arial','',10);
  
  $pdf->SetWidths(Array(35,30,30,30,30));

  $pdf->SetLineHeight(5);

  $pdf->SetFont('Arial','B',10);
  
  $pdf->Cell(35,5,"Panchayath Name",1,0);
  $pdf->Cell(30,5,"Ward Number",1,0);
  $pdf->Cell(30,5,"No of Positives",1,0);
  $pdf->Cell(30,5,"No of Contacts",1,0);
  $pdf->Cell(30,5,"No of Deaths",1,0);
  
  $pdf->Ln();
  
  $pdf->SetFont('Arial','',10);	
  
  foreach($result as $row) {
    $pdf->Row(Array(
        $row['panch_name'],
        $row['ward_num'],
		$row['no_of_pstvs'],
		
        $row['no_of_contacts'],
		$row['no_of_deaths'],
		
	));
	
  }
  $pdf->Output();
}
?>
