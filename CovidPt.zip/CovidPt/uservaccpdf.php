<?php
session_start();
include 'connection.php';

if (isset($_SESSION['id'])) 
{    

   $pid=$_GET['uid'];
    $ri=$_SESSION['id'];


         $result=mysqli_query($conn,"SELECT `tbl_usvacc`.*,tbl_register.*,tbl_hosvaccsch.*,tbl_hosvacc.*,tbl_vacc.vac_name,tbl_hospital.name FROM tbl_usvacc JOIN tbl_register ON tbl_usvacc.user_id=tbl_register.r_id JOIN tbl_hosvaccsch ON tbl_hosvaccsch.hvs_id=tbl_usvacc.hvs_id JOIN
         tbl_hosvacc ON tbl_hosvacc.hvac_id=tbl_hosvaccsch.hvac_id JOIN tbl_vacc ON tbl_vacc.vac_id=tbl_hosvacc.vac_id JOIN tbl_hospital ON tbl_hospital.h_id=tbl_hosvacc.hos_id AND tbl_usvacc.uvc_id='$pid'") or die(mysqli_error($con));

// $result=mysqli_query($con,"SELECT first_name,last_name,age,gender,parent_name,paddress,caddress,email,phone_no,license_type,date_of_issue,expiriry_date,blood FROM `tbl_drivinglicense` where driving_id=$driving_id") or die(mysqli_error($con));


include('pdf_table.php');
$pdf = new PDF_MC_TABLE();
$pdf->AddPage();
$pdf->SetFont('Arial','B',15);
$pdf->Image('assets\img\cer1.png',60,8,93);	
$pdf->Cell(176, 5, 'Certificate', 0, 0, 'C');
  $pdf->Ln();
  $pdf->Ln();
  $pdf->Ln();	
  $pdf->Ln();	
  $pdf->Ln();	
  $pdf->Ln();	
  $pdf->Ln();	
  $pdf->Ln();	
$row=mysqli_fetch_array($result);
$pdf->SetFont('Arial','',12);	
$pdf->Multicell(80,12,'Name : '. $row['uvname'],1);
$pdf->Multicell(80,12,'Age : '. $row['uvage'],1);
$pdf->Multicell(80,12,'Adhar : '. $row['uvadhar'],1);

$pdf->Multicell(80,12,'Vaccine Name : '. $row['vac_name'],1);
$pdf->Multicell(80,12,'Vaccine Dose : '. $row['vdose'],1);
$pdf->Multicell(80,12,'Date : '. $row['vdate'],1);
$pdf->Multicell(80,12,'Vaccinated Place : '. $row['name'],1);



$pdf->Output();


}
?>