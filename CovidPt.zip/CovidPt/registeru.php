<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta http-equiv="X-UA-Compatible" content="ie=edge">
	<title>Covid Preventocity</title>

	<!-- Font Icon -->
	<link rel="stylesheet" href="reassets/fonts/material-icon/css/material-design-iconic-font.min.css">

	<!-- Main css -->
	<link rel="stylesheet" href="reassets/css/style.css">

	<script type="text/javascript">
  
  var emailreg = /^([A-Za-z0-9_\-\.])+\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{2,4})$/;
  
	function doSubmit()
	{
		var illegalChars = /\W/; // allow letters, numbers, and underscores
		
		
	  if(document.getElementById('name').value == "")
		{
			alert("Please Enter Your Name");
			document.getElementById("form2").name.focus();
		}
		else if( /[^a-zA-Z ]/.test( document.getElementById('name').value ) ) 
		{
		   alert('Name is not alphanumeric');
		   document.getElementById("form2").name.focus();
		}
		else if(document.getElementById('panch').value == "")
		{
			alert("please select  panchayath");
			document.getElementById('form2').panch.focus();
		} 
        else if(document.getElementById('mobile').value == "")
		{
			alert("Please Enter Mobile");
			document.getElementById('form2').mobile.focus();
		}
		else if(isNaN(document.getElementById('mobile').value))
		{
			alert("Mobile Should Be A Number");
			document.getElementById('form2').mobile.focus();
		}
		else if(document.getElementById('mobile').value.length != 10)
		{
			alert("Invalid Mobile Number");
			document.getElementById('form2').mobile.focus();
		} 
		
		 else if(document.getElementById('emailid').value == "")
		{
			alert("Please Enter Email ID");
			document.getElementById('form2').emailid.focus();
		}
		else if(emailreg.test(document.getElementById('emailid').value) == false)
		{
			alert("Invalid Email ID");
			document.getElementById('form2').emailid.focus();
		} 
        else if(document.getElementById('username').value == "")
		{
			alert("Please Enter User Name");
			document.getElementById('form2').username.focus();
		}
		else if (illegalChars.test(username.value)) 
		{
			alert("Username can accept alphabets numbers and underscore only");
			document.getElementById('form2').username.focus();
		}
		else if(document.getElementById('username').value.length <=4)
		{
			alert("Username is too short");
			document.getElementById('form2').username.focus();
		}
		else if(document.getElementById('username').value.length >=15)
		{
			alert("Username is long");
			document.getElementById('form2').username.focus();
		}

		else if(document.getElementById('passwd').value == "")
		{
			alert("Please Enter Password");
			document.getElementById('form2').passwd.focus();
		}
		else if(document.getElementById('passwd').value.length <=4)
		{
			alert("Password is too short");
			document.getElementById('form2').passwd.focus();
		}
		else if(document.getElementById('passwd').value.length >=15)
		{
			alert("Password is long");
			document.getElementById('form2').passwd.focus();
		}
		else if(document.getElementById('passwd').value != document.getElementById('cpasswd').value)
		{
			alert("Passwords Should Match");
			document.getElementById('form2').cpasswd.focus();
		}
		
		else
		{
			document.getElementById('form2').action = 'reginsert.php';
	        document.getElementById('form2').submit();
		}
	}
    </script>
</head>

<body>

	<div class="main">

		<section class="signup">

			<div class="container">
				<div class="signup-content">
					<form method="POST" action="" id="form2" name="form2" autocomplete="off" class="signup-form">
						<h2 class="form-title">Registration</h2>
						<div class="form-group">
							Name:
							<input type="text" class="form-input" name="name" id="name" placeholder="Your Name" />
						</div>

						<div class="form-group">
							Panchayath Name:
							<!--<input type="text" class="form-input" name="panch" id="panch" placeholder="Your Panchayath"/> -->
							<select name='panch' class="form-input" id='panch' placeholder="Your panchayath">
								<option> </option>

								<?php
								$conn = mysqli_connect('localhost', 'root', '', 'covidpt');
								$query = mysqli_query($conn, "select * from tbl_panchayath");
								while ($row = mysqli_fetch_array($query)) {
								?>
									<option value="<?php echo $row['panch_id']; ?>"><?php echo $row['panch_name']; ?> </option>
								<?php
								}
								?>

							</select>
						</div>
						<div class="form-group">
							Mobile Number:
							<input type="text"  class="form-input" name="mobile" id="mobile" placeholder="Your Mobile Number" />
						</div>
						<div class="form-group">
							Email:
							<input type="email" class="form-input" name="emailid" id="emailid" placeholder="Your Email" />
						</div>
						<div class="form-group">
							UserName:
							<input type="text" class="form-input" name="username" id="username" placeholder="Your UserName" />
						</div>
						<div class="form-group">
							Password:
							<input type="password" class="form-input" name="passwd" id="passwd" placeholder="Password" />
							<!--<span toggle="#password" class="zmdi zmdi-eye field-icon toggle-password"></span>-->
						</div>
						<div class="form-group">
							Confirm Password:
							<input type="password" class="form-input" name="cpasswd" id="cpasswd" placeholder="Repeat your password" />
						</div>
						<div class="form-group">
							<input type="checkbox" name="agree-term" id="agree-term" class="agree-term" />
							
						</div>
						<div class="form-group">
							<input type="submit" name="submit" id="submit" onclick='doSubmit();' value='Submit' class="form-submit" />
						</div>
					</form>
					<p class="loginhere">
						Have already an account ? <a href="login.php" class="loginhere-link">Login here</a>
					</p>
				</div>
			</div>
		</section>

	</div>

	<!-- JS -->
	<script src="reassets/vendor/jquery/jquery.min.js"></script>
	<script src="reassets/js/main.js"></script>
</body><!-- This templates was made by Colorlib (https://colorlib.com) -->

</html>