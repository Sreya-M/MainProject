<?php
	$pat_id=$_GET['uid'];
	include('connection.php');

    $query = "select * from tbl_covpat where cpat_id='$pat_id'";
    $res = mysqli_query($conn, $query);
    $r = mysqli_fetch_array($res);
    $lid=$r["login_id"]; 
    $pa="Discharged";

	
	mysqli_query($conn,"update `tbl_covpat` set status='$pa' where cpat_id='$pat_id'");
	header('location:patients.php');
?>