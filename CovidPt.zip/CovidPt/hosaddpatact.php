
<?php 
session_start();
include 'connection.php';
if (isset($_SESSION['id'])) {


$ri = $_SESSION['id'];

$name=$_POST['name'];
$age=$_POST['age'];
$panch=$_POST['panch'];
$mob=$_POST['mobile'];

                $ri = $_SESSION['id'];
                $query = "select * from tbl_hospital where login_id='$ri'";
                $res = mysqli_query($conn, $query);
                $r = mysqli_fetch_array($res);
                $pid=$r["h_id"]; 
		  
	
		$sql1="INSERT INTO `tbl_covpat`(`panch_id`, `hos_id`, `name`, `age`, `mobile`, `status`)
         VALUES ('$panch','$pid','$name','$age','$mob','Admitted')";
         
       if(mysqli_query($conn,$sql1))
	   {
		   if(headers_sent()){
		   die('<script type="text/javascript">window.location.href="patients.php?e=1"</script>');
		   }
		   else {
		   header("location:patients.php?e=1");
		   die();
		   }
	   }
	
  
 
  else {

	echo "Error: " . $sql . "<br>" . mysqli_error($conn);
  }
}
  mysqli_close($conn);
?>
